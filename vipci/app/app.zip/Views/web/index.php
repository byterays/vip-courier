<html lang="en" class="webkit chrome chrome101 win win8 js orientation_landscape minw_1200 maxw_9999 no-hidpi datauri wf-poppins-n4-active wf-poppins-n5-active wf-poppins-n6-active wf-poppins-n7-active wf-roboto-n1-active wf-roboto-n3-active wf-roboto-n4-active wf-roboto-n5-active wf-roboto-n7-active wf-roboto-n9-active wf-opensans-n4-active wf-opensans-n6-active wf-opensans-n7-active wf-opensans-n8-active wf-active" style="margin-right: 100px; overflow: hidden;"><!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta name="csrf-token" content="Bc4iyDMhvZjJLXs1Q32PgfczTgOl5JnimEgHAAyg">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="stylesheet" href="html/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title> vip courier and cargo </title>
    <meta name="description" content="vip courier and cargo">
    <meta name="keywords" content="">
    <link rel="shortcut icon" href="favicon.html" type="image/x-icon">
    <link rel="shortcut icon" href="html/assets/lte/media/logos/favicon.ico">

    <meta property="og:url" content="en">
    <meta property="og:title" content=" vip courier and cargo">
    <meta property="og:description" content="vip courier and cargo">
    <meta property="og:type" content="website">
    <meta property="og:image" content="">
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="//ajax.googleapis.com/ajax/libs/webfont/1/webfont.js" type="text/javascript" async=""></script>
    <script type="text/javascript" src="html/assets/js/jquery/jquery.js"></script>
    <script type="text/javascript" src="html/assets/js/jquery/jquery-migrate.min.js"></script>
    <script type="text/javascript" src="html/assets/js/plugins.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js"></script>
    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <link rel="stylesheet" href="html/easyship/assets/css/style.css">
    <link rel="stylesheet" id="wooohoo-ilightbox-skin-css" href="html/assets/css/ilightbox/dark-skin/skin.css" type="text/css" media="all">
    <link rel="stylesheet" id="wooohoo-ilightbox-skin-black-css" href="html/assets/css/ilightbox/metro-black-skin/skin.css" type="text/css" media="all">
    <link rel="stylesheet" id="bdaia-woocommerce-css" href="html/assets/css/woocommerce.css" type="text/css" media="all">
    <link rel="stylesheet" href="html/assets/css/fontawesome-min.css">
    <link rel="stylesheet" href="html/custom-assets/css/app.css">
    <link rel="stylesheet" id="kolyoum-default-css" href="html/easyship/assets/css/post.style.css" type="text/css" media="all">
    <link rel="preconnect" href="//fonts.googleapis.com/">
    <link rel="preconnect" href="//fonts.gstatic.com/" crossorigin="">
    <link rel="dns-prefetch" href="http://fonts.googleapis.com/">
    <link href="//fonts.gstatic.com/" crossorigin="" rel="preconnect">
    <link rel="preload" as="script" href="//ajax.googleapis.com/ajax/libs/webfont/1/webfont.js">
    <style type="text/css">
        p.pra {
            font-size: 15px;
        }

        #good-hands .container .contents .wrapper {
            right: 620px;
            width: 44%;
            height: fit-content;
            margin-top: -12rem;
        }

        #good-hands .container {
            padding: 15px 0 86px 500px !important;
            /* width: 960px !important; */
            position: relative;
        }

        i.fa.fa-facebook {
            font-size: 14px;
            color: #fff;
            padding-right: 10px;
        }

        i.fa.fa-twitter {
            font-size: 14px;
            color: #fff;
            padding-right: 10px;
        }

        i.fa.fa-youtube {
            font-size: 14px;
            color: #fff;
            padding-right: 10px;
        }

        i.fa.fa-linkedin {
            font-size: 14px;
            color: #fff;
            padding-right: 10px;
        }

        i.fa.fa-instagram {
            font-size: 14px;
            color: #fff;
            padding-right: 10px;
        }

        .header-area {
            border-bottom: 1px solid #ffd799;
            padding-top: 11px;
            padding-bottom: 14px;
            background: #000;
        }

        span.vb {
            color: #fff;
            font-size: 13px;
            font-weight: 600;
            margin-left: 15px;
        }

        span.vb a {
            font-size: 14px !important;
        }

        .header-icon.text-md-right a {
            font-size: 14px !important;
        }

        .header-text {
            background-color: #000;
        }

        li.mn {
            font-size: 15px;
        }

        img.my_img {
            width: 153px;
            padding: 0px;
            margin: 0px;
            margin-top: 10px;

        }

        .dropdowns {
            cursor: pointer;
            display: none;
        }


        .mobile-top.mobile-view {
            display: none;
        }

        @media only screen and (max-width: 600px) {

            .mobile-top.mobile-view {
                background: #000;
                display: block;
                padding-top: 10px;
                padding-bottom: 10px;
            }

            .mobile-top.mobile-view {
                background: #000;
                display: block;
                padding-top: 10px;
                padding-bottom: 10px;
            }

            .mobile-top.mobile-view {
                background: #000;
                display: block;
            }

            .mobile-top.mobile-view {
                background: #000;
                display: block;
                padding-top: 610;
                padding-bottom: 10px;
            }

            i.fa.fa-envelope-open-o {
                color: #fff;
                font-weight: 600;
                font-size: 12px;
            }

            i.fa.fa-envelope-open-o {
                margin-right: 0px !important;
                font-size: 10px !important;
            }

            a.text-white {
                font-size: 10px;
                /* padding-top: 34px !important; */
                font-weight: 500;
                color: #fff;
            }

            i.fa.fa-phone-volume {
                color: #fff;
                font-size: 12px;
            }

            i.fa.fa-phone-volume {
                margin-right: 0px !important;
                font-size: 16px !important;
            }


            a.text-white.hb {
                font-size: 13px !important;
                margin-left: 0px !important;
            }

            .far-envelope-open:before {
                content: "\f2b6" !important;
            }

            h2.heading.gb {
                margin-top: 58px;
                font-family: poppins;
            }

            a.text-white {
                font-size: 10px;
                /* padding-top: 34px !important; */
                font-weight: 500;
            }

            i.fa.fa-phone-volume {
                color: #fff;
                font-size: 15px;
            }

            .text-right {
                text-align: right !important;
            }

            i.fa.fa-envelope-open-o {
                color: #fff;
                font-weight: 600;
                font-size: 12px;
            }

            a.text-white.hb {
                margin-left: 6px;
                font-size: 15px;
            }

            .mobile-top.mobile-view {
                background: #000;
                display: block;
            }

            .mobile-top.mobile-view {
                background: #000;
                display: block;
                padding-top: 6px;
                padding-bottom: 6px;
            }

            #good-hands .container {
                margin: 0 30px;
                padding: 60px 0 115px !important;
                position: relative;
            }

            #good-hands .container .contents .wrapper {
                right: 620px;
                width: 100%;
                height: fit-content;
                margin-top: 0px;
            }

            a.text-white.hb {
                font-size: 13px !important;
                margin-left: 0px !important;
            }

            .bd-content-wrap {
                padding-top: 0px !important;
                padding-bottom: 32px;
            }

            .my-widget {
                margin-bottom: 0px !important;
            }

            #main-header .navbar .container {
                padding-block: 0px !important;
                -webkit-perspective: 2000px;
                perspective: 2000px;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-pack: justify;
                -ms-flex-pack: justify;
                justify-content: space-between;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
            }

            #banner .container {
                margin: 0 30px;
                padding: 50px 0;
                border-bottom: 1px solid #dfe3e8;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                -ms-flex-direction: column;
                flex-direction: column;
                -webkit-box-align: start;
                -ms-flex-align: start;
                align-items: flex-start;
                margin-top: 0px !important;
                padding-top: 0px !important;
            }

            a.text-white.hb {
                margin-left: 6px;
                font-size: 15px;
            }

            .far-envelope-open:before {
                content: "\f2b6" !important;
            }

            h2.heading.gb {
                margin-top: 58px;
                font-family: poppins;
            }

            a.text-white {
                font-size: 10px;
                /* padding-top: 34px !important; */
                font-weight: 600;
            }

            i.fa.fa-phone-volume {
                color: #fff;
                font-size: 15px;
            }

            .text-right {
                text-align: right !important;
            }

            i.fa.fa-envelope-open-o {
                color: #fff;
                font-weight: 600;
                font-size: 12px;
            }

            .mobile-top.mobile-view {
                background: #000;
                display: block;
            }


        }



        @media only screen and (max-width: 900px) {

            .bd-push-menu-open aside.bd-push-menu,
            aside.bd-push-menu.light-skin {
                background: #fe4f2d;
                background: -webkit-linear-gradient(176deg, #cf109f, #fe4f2d);
                background: linear-gradient(176deg, #cf109f, #fe4f2d);
            }
        }

        @media only screen and (max-width: 900px) {
            div.bd-push-menu-inner::before {
                background-image: url("html/assets/images/dsfdsfsddfsfd.jpg") !important;
                background-repeat: no-repeat;
                background-attachment: scroll;
                background-position: center;
                background-position: center;
            }
        }

        div.bdaia-footer,
        div.bdaia-footer.bd-footer-light {
            background: #111026;
            background: -webkit-linear-gradient(176deg, #111026, #111026);
            background: linear-gradient(176deg, #111026, #111026);
        }

        div.bdaia-footer::before {
            background-image: url("html/assets/images/footer-background.svg") !important;
            background-repeat: no-repeat;
            background-attachment: scroll;
            background-position: center top;
        }

        .bd-cat-10 {
            background: #e5b22b !important;
            color: #FFF !important;
        }

        .bd-cat-10::after {
            border-top-color: #e5b22b !important
        }

        .bd-cat-13 {
            background: #39a657 !important;
            color: #FFF !important;
        }

        .bd-cat-13::after {
            border-top-color: #39a657 !important
        }

        .bd-cat-8 {
            background: #6b45e0 !important;
            color: #FFF !important;
        }

        .bd-cat-8::after {
            border-top-color: #6b45e0 !important
        }

        .bd-cat-12 {
            background: #e81055 !important;
            color: #FFF !important;
        }

        .bd-cat-12::after {
            border-top-color: #e81055 !important
        }

        .bdaia-header-default .topbar:not(.topbar-light) {
            background: #fb8332
        }

        .bdaia-header-default .topbar:not(.topbar-light) {
            background: linear-gradient(176deg, #fb8332 0, #b31919 100%);
        }

        .bdaia-header-default .header-container {
            border-bottom: 0 none;
        }

        ul.bd-components>li.bd-alert-posts {
            padding-right: 0;
        }

        .bdaia-header-default .header-container .bd-container {
            background: url("html/assets/images/top-shadow.png") no-repeat top;
        }

        .bdaia-header-default .topbar.topbar-gradient .breaking-title {
            background-color: rgba(0, 0, 0, .75);
            border-radius: 2px;
        }

        .inner-wrapper {
            background-color: #FFF;
        }

        .article-meta-info .bd-alignleft .meta-item:last-child {
            margin-right: 0;
        }

        .article-meta-info .bd-alignright .meta-item:first-child {
            margin-left: 0;
        }

        .articles-box-dark.articles-box.articles-box-block625 .articles-box-items>li:first-child {
            border-bottom: 1px solid rgba(255, 255, 255, .1);
        }

        .articles-box.articles-box-block614 .articles-box-items>li .article-details h3 {
            padding: 0;
            font-size: 19px;
            line-height: 1.33;
            font-weight: normal;
        }

        .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li:hover>a,
        .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li.current-menu-item>a,
        .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li.current-menu-ancestor>a,
        .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li.current-menu-parent>a {
            background-color: #105EFB !important;
        }

        .bdaia-header-default #navigation .primary-menu ul#menu-primary>li>.bd_mega.sub-menu,
        .bdaia-header-default #navigation .primary-menu ul#menu-primary>li>.sub-menu {
            border-color: #105EFB !important;
        }

        .bdaia-header-default #navigation.dropdown-light .primary-menu ul#menu-primary li.bd_mega_menu div.bd_mega ul.bd_mega.sub-menu li a:hover,
        .bdaia-header-default #navigation.dropdown-light .primary-menu ul#menu-primary li ul.sub-menu li a:hover {
            color: #105EFB !important;
        }
    </style>

    <style type="text/css" media="all">
        :root {
            --brand-color: #EE6517;
            --dark-brand-color: #F65051;
            --bright-color: #FFF;
            --base-color: #161D40;
        }

        body {
            color: var(--base-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Poppins, Oxygen, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", "Open Sans", Arial, sans-serif;
            font-size: 13px;
            line-height: 21px;
        }

        * {
            padding: 0;
            margin: 0;
            list-style: none;
            border: 0;
            outline: none;
            box-sizing: border-box;
        }

        a {
            color: var(--base-color);
            text-decoration: none;
            transition: 0.15s;
        }

        a:hover {
            color: var(--brand-color);
        }

        a:active,
        a:hover {
            outline-width: 0;
        }

        div.hero section#banner.section {
            background: #FFFFFF !important;
        }

        #main-header:hover,
        #main-header.active {
            -webkit-box-shadow: none !important;
            box-shadow: none !important;
        }

        #main-header .navbar .logo {
            -webkit-margin-end: 90px;
            margin-inline-end: 90px;
        }

        #main-header .navbar .nav-list>li {
            padding-inline: 0;
            -webkit-margin-end: 40px;
            margin-inline-end: 40px;
        }

        #main-header .navbar .nav-list>li a {
            font-size: 14px;
            font-weight: bold;
            letter-spacing: 0;
            text-transform: uppercase;
            color: var(--base-color) !important;
        }

        #main-header .navbar .nav-list>li a:hover {
            color: var(--brand-color) !important;
        }

        #main-header .navbar .nav-list .dropdown-menu.submenu,
        #main-header .navbar .nav-list .dropdown-menu {
            border-radius: 0 !important;
            width: 230px !important;
            padding: 10px 0 !important;
            line-height: 20px !important;
            box-shadow: 0 15px 30px rgb(0 0 0 / 06%), 0 0 0 1px rgb(0 0 0 / 4%);
        }

        #main-header .navbar .nav-list .dropdown-menu.submenu a,
        #main-header .navbar .nav-list .dropdown-menu a {
            display: block;
            margin: 0 !important;
            padding: 8px 20px !important;
            min-height: unset !important;
            font-size: 13px !important;
            text-transform: unset !important;
            font-weight: normal !important;
            color: var(--base-color) !important;
            max-width: 100% !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
        }

        #main-header .navbar .nav-list .dropdown-menu.submenu a:hover,
        #main-header .navbar .nav-list .dropdown-menu a:hover {
            color: var(--brand-color) !important;
        }

        #main-header .navbar .nav-list li,
        #main-header .navbar .nav-list .dropdown-item {
            height: unset !important;
            max-height: unset !important;
            padding-block: unset !important;
        }

        #main-header .navbar .nav-list ul {
            line-height: 20px;
            z-index: 1;
            top: unset !important;
            left: unset !important;
        }

        #main-header .navbar .nav-list ul ul {
            top: 0 !important;
            left: 100% !important;
            margin-top: -10px !important;
        }

        #main-header .navbar .nav-list li svg {
            display: none !important;
        }

        #banner .btn {
            padding: 22px 40px;
            height: unset;
            border-radius: 10px !important;
            box-shadow: none !important;
            font-size: 18px;
            font-weight: 600;
            margin: 30px 0 0 0;
            font-family: 'Poppins';
            text-transform: unset !important;
        }

        .section .intro .heading {
            font-family: 'Poppins';
            font-weight: 600;
            letter-spacing: -2px;
        }

        @media only screen and (min-width: 75rem) {
            #banner .container {
                padding: 145px 0;
            }

            #banner .container {
                padding: 145px 0;
                padding-top: 0px !important;
            }
        }

        @media (min-width: 62rem) {
            section#banner div.wrapper {
                height: 100% !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
            }

            section#banner div.wrapper img {
                max-width: 700px !important;
                max-height: unset !important;
                margin-left: auto !important;
            }

            #good-hands .intro {
                text-align: unset !important;
            }

            section.section .intro h2.heading {
                max-width: 700px !important;
                margin-left: auto !important;
                margin-right: auto !important;
                margin-top: unset !important;
            }

            section.section {}
        }

        .bdaia-post-content blockquote {
            padding: 0 1em !important;
            margin: 40px 0 38px 0 !important;
            border-left: .25em solid !important;
            overflow-wrap: break-word !important;
        }


        .column-info img {
            width: 100%;
            height: auto;
        }

        .img-thumbnail {
            display: inline-block;
            max-width: 100%;
            height: auto;
            padding: 4px;
            line-height: 1.42857143;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            -webkit-transition: all .2s ease-in-out;
            -o-transition: all .2s ease-in-out;
            transition: all .2s ease-in-out;
        }

        body,
        .column-info>div>span,
        .bg-image .one-news>div>div,
        .bg-image .two-news>div div:last-child>div,
        .main-menu a:after,
        #to-top:hover,
        .btn.btn-sm.btn-success,
        .darken-block .testimonial-content,
        #testimonials .owl-buttons div,
        ul.blog-cats li:hover:before {
            background-color: #fff;
        }

        .column-info>div>span {
            display: block;
            float: right;
            margin-top: -20px;
            margin-right: -8px;
            position: relative;
            z-index: 2;
            height: 20px;
            width: 60px;
            -webkit-transform: skew(-30deg);
            -moz-transform: skew(-30deg);
            -o-transform: skew(-30deg);
        }

        .column-info h3 {
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 16px;
            text-align: center;
            FONT-WEIGHT: 700;
        }

        .banner_bottom_section P {
            font-size: 15px;
            font-weight: 500;
            color: #000;
        }

        .btn.btn-sm {
            font-weight: 400;
            padding: 10px 20px 8px 20px;
            border: 1px solid #eeeeee;
            font-size: 11px;
            width: 35%;
            margin: 0 auto;
            /* float: none; */
            text-align: center;
            display: block;
            background: #f1f1f1;
        }

        .btn.btn-sm {
            padding: 0 15px;
            min-height: unset;
            height: 35px !important;
            font-size: .8125rem;
            line-height: 30px;
            font-size: 13px !important;
            font-weight: 600;
            font-family: poppins;
            position: relative !important;
            z-index: 0;
        }

        .btn {
            font-family: Roboto-bold;
            position: relative;
            font-size: 12px !important;
            padding: 5px 20px 5px 8px;
            border: none;
            text-transform: uppercase;
            border-radius: 0px;
        }

        .navbar-main>li>.dropdown-menu,
        footer .color-part,
        .btn.btn-danger,
        .btn.btn-danger:hover,
        .btn.btn-danger,
        .btn.btn-danger:hover,
        .main-menu,
        .main-menu:before,
        #main-menu-bg,
        .stats>div>div:hover,
        .btn.btn-sm.btn-default:before,
        .big-hr.color-2,
        .our-services.styled div>a:hover:after,
        .adress-details>div>span:after,
        .comments>div>a.reply:hover,
        .comments>div>a.reply:after,
        nav.pagination a:hover,
        .tags a:hover,
        ul.blog-cats>li:hover,
        #menu-open,
        .main-menu section nav,
        .our-services div>a:hover>span,
        .testimonial-content span,
        .info-texts:after,
        .post-info:after,
        .customBgColor {
            background-color: #f16e26;
        }

        .btn.btn-sm:hover:before {
            width: 100%;
            z-index: -1;
        }

        .btn.btn-sm:before {
            content: "";
            display: block;
            position: absolute;
            right: 0px;
            top: -1px;
            bottom: -1px;
            width: 4px;
            opacity: 1;
            transition: 0.4s;
            transition-timing-function: cubic-bezier(.36, .99, .69, 1.2);
            z-index: 1;
        }

        .testimonial-content span,
        .bg-image h1,
        .why-us li span,
        .stats>div>div:hover,
        .slider-content a.prev,
        .slider-content a.next,
        .big-hr,
        .big-hr h2,
        .contact-info strong,
        .footer-icons a:hover,
        .contact-info i,
        footer h4,
        footer nav a:hover,
        .topmenu a,
        .btn.btn-sm.btn-default:hover,
        .btn.btn-sm.btn-success:hover,
        .btn.btn-success,
        .btn-success:hover,
        .btn.btn-danger,
        .btn.btn-danger:hover,
        .main-menu a,
        .slider-content,
        .slider-content h1,
        #to-top,
        .blog-section h3,
        .one-news>div>div small,
        .two-news>div div:last-child small,
        .blog-section div div a,
        .blog-section div div a:hover,
        #fleet-gallery .owl-buttons div,
        .page-title,
        .page-title a,
        .page-title a:hover,
        .team>div>div span,
        .comments>div>a.reply:hover,
        nav.pagination a:hover,
        nav.pagination a.active,
        .tags a:hover,
        ul.blog-cats>li:hover>a {
            color: #fff;
        }

        .column-info a.btn {
            margin-top: 0px;
        }

        .btn {
            font-family: Roboto-bold;

            font-size: 12px !important;
            padding: 5px 20px 5px 8px;
            border: none;
            text-transform: uppercase;
            border-radius: 0px;
        }

        .stats>div>div:hover,
        .btn.btn-sm.btn-default:hover,
        .comments>div>a.reply:hover,
        nav.pagination a:hover,
        .tags a:hover,
        ul.blog-cats li:hover,
        .our-services div>a:hover>span,
        .testimonial-content span {
            border-color: #f16e26;
        }

        .banner_bottom_section h1 {
            font-weight: 500;
        }

        .cs_top_services_wrapper {
            background: #f8f8f8;
            padding: 60px 0px;
            margin-top: 80px;
        }

        .cs_top_services_box {
            text-align: center;
            background: #fff;
            padding: 25px 10px;
            border-radius: 20px;
            box-shadow: 0 1px 23px rgb(255 255 255 / 12%), 0 1px 19px rgb(255 255 255 / 24%);
            transition: all 0.5s;
        }

        .cs_top_services_icon {
            margin-top: 10px;
        }

        .cs_top_services_box {
            text-align: center;
            background: #fff;
            padding: 25px 10px;
            border-radius: 20px;
            box-shadow: 0 1px 23px rgb(255 255 255 / 12%), 0 1px 19px rgb(255 255 255 / 24%);
            transition: all 0.5s;
        }

        .cs_top_services_box {
            text-align: center;
            background: #fff;
            padding: 25px 10px;
            border-radius: 20px;
            box-shadow: 0 1px 23px rgb(255 255 255 / 12%), 0 1px 19px rgb(255 255 255 / 24%);
            transition: all 0.5s;
        }

        input,
        textarea,
        select,
        button,
        label,
        svg,
        svg path,
        svg rect,
        svg polygon,
        img,
        a,
        :after,
        :before,
        :hover,
        :focus,
        .form-control:focus {
            outline: none !important;
            box-shadow: none;
        }

        .cs_top_services_icon p {
            color: #66728d;
            transition: all 0.5s;
            font-weight: 500;
            font-size: 16px;
        }

        .cs_top_services_box:hover {
            text-align: center;
            background: #f16e26;
            padding: 25px 10px;
            border-radius: 20px;
            box-shadow: 0px 29px 60px 0px rgba(255, 90, 96, 0.4);
            color: #fff;
        }

        .cs_top_services_box:hover .cs_top_services_icon p {
            color: #fff;
        }

        .banner_bottom_section {
            padding: 50px 0px;
        }

        .cs_about_wrapper {
            padding: 80px 0 0;
        }

        .cs_about_img {
            padding-left: 120px;
        }

        .cs_about_content h5 {
            color: #f16e26;
            font-size: 18px;
            font-weight: 500;
            letter-spacing: 3px;
            text-transform: uppercase;
        }

        .cs_about_content h1 {
            color: #2c3e4a;
            font-size: 43px;
            font-weight: 500;
            margin-top: 15px;
            position: relative;
            padding-bottom: 10px;
        }

        .cs_about_content h1:after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 80px;
            height: 3px;
            background: #f16e26;
        }

        ul {
            padding: 0;
            margin: 0;
            list-style-type: none;
        }

        .cs_about_icon_box {
            display: flex;
            align-items: center;
            margin-top: 40px;
        }

        .cs_about_icon_text {
            margin-left: 35px;
        }

        .cs_about_icon_text h3 {
            color: #2c3e4a;
            font-size: 20px;
            font-weight: bold;
            margin: 0px;
        }

        .cs_about_icon_text p {
            font-size: 16px;
        }

        #myButton {
            bottom: 120px;
            left: 30px;
            position: fixed;
            transform-origin: bottom;
            z-index: 999;
        }

        #myCall img,
        #myButton img {
            width: 50px;
            border-radius: 100%;
        }

        #myCall {
            left: 30px;
            bottom: 60px;
            position: fixed;
            transform-origin: bottom;
            z-index: 999;
        }

        .road-section-divider {
            background-image: url(html/assets/road.png);
            width: 100%;
            background-repeat: no-repeat;
            height: 58px;
            overflow: hidden;
        }

        .road-border {
            -webkit-transition: all 0.5s ease-out;
            transition: all 0.5s ease-out;
            -webkit-animation: s3-rotate 17s infinite linear;
            animation: s3-rotate 17s infinite linear;
            display: block;
            position: relative;
            top: 3px;
        }

        .road-border img {
            width: 100px;
        }

        @-webkit-keyframes s3-rotate {
            from {
                -webkit-transform: translateX(0%);
            }

            to {
                -webkit-transform: translateX(105%);
            }
        }

        .cta-area {
            padding: 100px 0 0;
            background: -moz-linear-gradient(-45deg, #8400fc 0%, #11def4 100%);
            background: -webkit-linear-gradient(-45deg, #8400fc 0%, #11def4 100%);
            background: linear-gradient(135deg, #8400fc 0%, #11def4 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#8400fc', endColorstr='#11def4', GradientType=1);
            position: relative;
        }

        .cta-content {
            padding: 0 0 80px;
            text-align: center;
        }

        .cta-content h3 {
            color: #fff;
            margin: 0 0 25px;
            font-size: 25px;
            line-height: 40px;
        }

        .btn-style-one {
            position: relative;
            display: inline-block;
            font-size: 18px;
            line-height: 30px;
            color: #ffffff;
            padding: 13px 30px 11px;
            font-weight: 300;
            overflow: hidden;
            border-radius: 2px;
            background-color: #ff6907;
            text-transform: capitalize;
            font-family: 'Hind', sans-serif;
            cursor: poionter;
        }

        .btn-style-one::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            opacity: 0;
            background-color: #ffffff;
            -webkit-transition: all 0.4s;
            -moz-transition: all 0.4s;
            -o-transition: all 0.4s;
            transition: all 0.4s;
            -webkit-transform: scale(1, 0.5);
            transform: scale(1, 0.5);
        }

        .btn-style-one .txt {
            position: relative;
            z-index: 1;
        }

        .ripple_wrap {
            overflow: hidden;
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            pointer-events: none;
        }

        .left_bottom_ripples {
            margin-bottom: -60vh;
            margin-left: -60vh;
            width: 120vh;
            height: 120vh;
            bottom: 0;
            position: absolute;
            left: 0;
        }

        .right_top_ripples {
            margin-top: -60vh;
            margin-right: -60vh;
            width: 120vh;
            height: 120vh;
            position: absolute;
            top: 0;
            right: 0;
        }

        .ripples:after,
        .ripples:before {
            content: "";
            top: 0;
            position: absolute;
        }

        .ripples,
        .ripples:after,
        .ripples:before {
            height: 100%;
            width: 100%;
        }

        .ripples:before {
            background: -webkit-radial-gradient(center, ellipse, rgba(182, 225, 235, 0) 0, rgba(182, 225, 235, .05) 40%, rgba(182, 225, 235, .4) 100%);
            background: -moz-radial-gradient(center, ellipse, rgba(182, 225, 235, 0) 0, rgba(182, 225, 235, .05) 40%, rgba(182, 225, 235, .4) 100%);
            background: -o-radial-gradient(center, ellipse, rgba(182, 225, 235, 0) 0, rgba(182, 225, 235, .05) 40%, rgba(182, 225, 235, .4) 100%);
            background: radial-gradient(ellipse at center, rgba(255, 255, 255, 0) 0, rgba(255, 255, 255, .05) 40%, rgba(255, 255, 255, .4) 100%);
            border-radius: 50%;
            opacity: 0;
            -webkit-transform: scale(1);
            -moz-transform: scale(1);
            -ms-transform: scale(1);
            -o-transform: scale(1);
            transform: scale(1);
            -webkit-animation-name: ripple1;
            -moz-animation-name: ripple1;
            -o-animation-name: ripple1;
            animation-name: ripple1;
            -webkit-animation-duration: 6s;
            -moz-animation-duration: 6s;
            -o-animation-duration: 6s;
            animation-duration: 6s;
            -webkit-animation-delay: 0s;
            -moz-animation-delay: 0s;
            -o-animation-delay: 0s;
            animation-delay: 0s;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-iteration-count: infinite;
            -o-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
            -webkit-animation-timing-function: linear;
            -moz-animation-timing-function: linear;
            -o-animation-timing-function: linear;
            animation-timing-function: linear;
        }

        .ripples:after {
            background: -webkit-radial-gradient(center, ellipse, rgba(182, 225, 235, 0) 0, rgba(182, 225, 235, .05) 40%, rgba(182, 225, 235, .4) 100%);
            background: -moz-radial-gradient(center, ellipse, rgba(182, 225, 235, 0) 0, rgba(182, 225, 235, .05) 40%, rgba(182, 225, 235, .4) 100%);
            background: -o-radial-gradient(center, ellipse, rgba(182, 225, 235, 0) 0, rgba(182, 225, 235, .05) 40%, rgba(182, 225, 235, .4) 100%);
            background: radial-gradient(ellipse at center, rgba(255, 255, 255, 0) 0, rgba(255, 255, 255, .05) 40%, rgba(255, 255, 255, .4) 100%);
            border-radius: 50%;
            opacity: 0;
            -webkit-animation-name: ripple1;
            -moz-animation-name: ripple1;
            -o-animation-name: ripple1;
            animation-name: ripple1;
            -webkit-animation-duration: 6s;
            -moz-animation-duration: 6s;
            -o-animation-duration: 6s;
            animation-duration: 6s;
            -webkit-animation-delay: 3s;
            -moz-animation-delay: 3s;
            -o-animation-delay: 3s;
            animation-delay: 3s;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-iteration-count: infinite;
            -o-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
            -webkit-animation-timing-function: linear;
            -moz-animation-timing-function: linear;
            -o-animation-timing-function: linear;
            animation-timing-function: linear;
        }

        @keyframes ripple1 {
            0% {
                -webkit-transform: scale(.01);
                -moz-transform: scale(.01);
                -o-transform: scale(.01);
                transform: scale(.01);
                opacity: 0
            }

            33% {
                -webkit-transform: scale(.4);
                -moz-transform: scale(.4);
                -o-transform: scale(.4);
                transform: scale(.4);
                opacity: .8
            }

            100% {
                -webkit-transform: scale(1);
                -moz-transform: scale(1);
                -o-transform: scale(1);
                transform: scale(1);
                opacity: 0
            }
        }

        @-webkit-keyframes fadeBlur {
            0% {
                opacity: 0;
                -webkit-transform: scale(1.1);
                -ms-transform: scale(1.1);
                transform: scale(1.1);
                filter: blur(10px);
            }

            100% {
                opacity: 1;
                -webkit-transform: scale(1);
                -ms-transform: scale(1);
                transform: scale(1);
                filter: blur(0px);
            }
        }

        @keyframes fadeBlur {
            0% {
                opacity: 0;
                -webkit-transform: scale(1.1);
                -ms-transform: scale(1.1);
                transform: scale(1.1);
                filter: blur(10px);
            }

            100% {
                opacity: 1;
                -webkit-transform: scale(1);
                -ms-transform: scale(1);
                transform: scale(1);
                filter: blur(0px);
            }
        }

        .fadeBlur {
            -webkit-animation-name: fadeBlur;
            animation-name: fadeBlur;
        }

        html:not(.ie-10):not(.ie-11):not(.ie-edge) .wave {
            height: auto;
        }

        .wave {
            position: relative;
            display: block;
            width: 100%;
            bottom: -1px;
        }

        .wave-dark {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: auto;
            pointer-events: none;
        }

        .wave-dark .wave-path {
            transform: scale(1.2, 1);
            transform-origin: 50% 100%;
        }

        .wave-dark .wave-path-1 {
            fill: rgba(255, 255, 255, 0.05);
            animation: wave1 15s ease-in-out infinite;
        }

        .wave-dark .wave-path-2 {
            fill: rgba(255, 255, 255, 0.02);
            animation: wave2 15s ease-in-out infinite;
        }

        .wave-dark .wave-path-3 {
            fill: rgba(255, 255, 255, 0.02);
            animation: wave3 15s ease-in-out infinite;
        }

        .wave-dark-1 {
            bottom: -52%;
        }

        .wave-dark-2 {
            bottom: -14%;
        }

        .wave-dark-3 {
            bottom: -76%;
        }

        .wave-dark-4 .wave-path-1 {
            display: none;
        }

        .wave-dark-5 {
            bottom: -28%;
        }


        #main-footer {
            padding-left: 2.03125rem;
            padding-right: 2.03125rem;
            background: #000 !important;

            color: #fff;
        }

        i.fa.fa-address-card-o {
            margin-right: 9px;
            font-size: 20px;
        }

        i.fa.fa-phone-volume {
            margin-right: 9px;
            font-size: 20px;
        }

        i.fa.fa-envelope-open-o {
            margin-right: 9px;
            font-size: 20px;
        }

        li.mn {
            margin-bottom: 12px;
        }

        a.text-white.hb {
            font-size: 17px;
        }
    </style>
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Poppins:regular,500,600,700%7CRoboto:100,300,400,500,700,900%7COpen+Sans:400,600,700,800&amp;subset=latin,latin,latin" media="all">






    <style>
        .theiaStickySidebar:after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
    <style>
        .theiaStickySidebar:after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>

<body class="home page-template-default page wp-embed-responsive has-lazy-load bdaia-popup-is-opend" itemscope="itemscope" itemtype="//schema.org/WebPage">


    <div class="bdaia-header-default">
        <header id="main-header" class="active light_style">


            <div class="header-area d-none d-md-block">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 col-lg-8 col-md-8">
                            <div class="header-wrapper">
                                <div class="header-text"> <span class="vb"> <i class="fa fa-map-o "></i>F 30/5 okhla phase 2 opp hdfc bank new delhi 110020</span> <span class="vb"> <i class="fa fa-envelope-open-o"></i> <a href="mailto: info@vipcourierandcargo.com" class="__cf_email__ text-white" data-cfemail=""> info@vipcourierandcargo.com</a></span> </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-2">
                            <div class="header-icon text-md-right"> <i style="color:#fff" class="fa fa-phone-volume"></i> <a style="font-weight:600" href="tel:918920095642" class="text-white">+918920095642</a> </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-2">
                            <div class="header-icon text-md-right"> <i style="color:#fff" class="fa fa-phone-volume"></i> <a style="font-weight:600" href="tel:919650086730" class="text-white">+919650086730</a> </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-top mobile-view">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <i class="fa fa-map-o" aria-hidden="true"></i> <a href="#" class="text-white">F 30/5 okhla phase 2 opp hdfc bank new delhi 110020</a>
                        </div>

                    </div>
                </div>
            </div>
            <style>
                /*----------bootstrap-navbar-css------------*/
                .navbar-logo {
                    padding: 0px 15px !important;
                    color: #fff;
                }

                .navbar-mainbg {
                    background-color: #ee6517;
                    padding: 0px;
                }

                #navbarSupportedContent {
                    overflow: hidden;
                    position: relative;
                }

                #navbarSupportedContent ul {
                    padding: 0px;
                    margin: 0px;
                }

                #navbarSupportedContent ul li a i {
                    margin-right: 10px;
                }

                #navbarSupportedContent li {
                    list-style-type: none;
                    float: left;
                }

                #navbarSupportedContent ul li a {
                    color: rgb(255 255 255 / 99%);
                    text-decoration: none;
                    font-size: 15px;
                    display: block;
                    padding: 20px 20px;
                    transition-duration: 0.6s;
                    transition-timing-function: cubic-bezier(0.68, -0.55, 0.265, 1.55);
                    position: relative;
                    font-weight: 600;
                }

                #navbarSupportedContent>ul>li.active>a {
                    color: #ee6517;
                    background-color: transparent;
                    transition: all 0.7s;
                    font-weight: 600;
                }

                #navbarSupportedContent a:not(:only-child):after {
                    content: "\f105";
                    position: absolute;
                    right: 20px;
                    top: 10px;
                    font-size: 14px;
                    font-family: "Font Awesome 5 Free";
                    display: inline-block;
                    padding-right: 3px;
                    vertical-align: middle;
                    font-weight: 900;
                    transition: 0.5s;
                }

                #navbarSupportedContent .active>a:not(:only-child):after {
                    transform: rotate(90deg);
                }

                .hori-selector {
                    display: inline-block;
                    position: absolute;
                    height: 100%;
                    top: 0px;
                    left: 0px;
                    transition-duration: 0.6s;
                    transition-timing-function: cubic-bezier(0.68, -0.55, 0.265, 1.55);
                    background-color: #fff;
                    border-top-left-radius: 15px;
                    border-top-right-radius: 15px;
                    margin-top: 10px;
                }

                .hori-selector .right,
                .hori-selector .left {
                    position: absolute;
                    width: 25px;
                    height: 25px;
                    background-color: #fff;
                    bottom: 10px;
                }

                .hori-selector .right {
                    right: -25px;
                }

                .hori-selector .left {
                    left: -25px;
                }

                .hori-selector .right:before,
                .hori-selector .left:before {
                    content: '';
                    position: absolute;
                    width: 50px;
                    height: 50px;
                    border-radius: 50%;
                    background-color: #ee6517;
                }

                .hori-selector .right:before {
                    bottom: 0;
                    right: -25px;
                }

                .hori-selector .left:before {
                    bottom: 0;
                    left: -25px;
                }

                .navbar-brand {

                    display: inline-block;
                    padding-top: .3125rem;
                    padding-bottom: .3125rem;
                    margin-right: 1rem;
                    font-size: 1.25rem;
                    line-height: inherit;
                    height: auto;
                    width: auto;
                }

                #main-header .navbar {
                    position: relative;
                    max-width: 100%;
                    padding: 0;
                    transition: background-color .3s ease, box-shadow .3s ease, -webkit-box-shadow .3s ease;
                    margin-top: -1px;
                }

                @media(min-width: 992px) {
                    .navbar-expand-custom {
                        -ms-flex-flow: row nowrap;
                        flex-flow: row nowrap;
                        -ms-flex-pack: start;
                        justify-content: flex-start;
                    }

                    .navbar-expand-custom .navbar-nav {
                        -ms-flex-direction: row;
                        flex-direction: row;
                    }

                    .navbar-expand-custom .navbar-toggler {
                        display: none;
                    }

                    .navbar-expand-custom .navbar-collapse {
                        display: -ms-flexbox !important;
                        display: flex !important;
                        -ms-flex-preferred-size: auto;
                        flex-basis: auto;
                    }
                }


                @media (max-width: 991px) {
                    #navbarSupportedContent ul li a {
                        padding: 12px 30px;
                    }

                    .hori-selector {
                        margin-top: 0px;
                        margin-left: 10px;
                        border-radius: 0;
                        border-top-left-radius: 25px;
                        border-bottom-left-radius: 25px;
                    }

                    .hori-selector .left,
                    .hori-selector .right {
                        right: 10px;
                    }

                    .hori-selector .left {
                        top: -25px;
                        left: auto;
                    }

                    .hori-selector .right {
                        bottom: -25px;
                    }

                    .hori-selector .left:before {
                        left: -25px;
                        top: -25px;
                    }

                    .hori-selector .right:before {
                        bottom: -25px;
                        left: -25px;
                    }

                    .banner_sec .my-widget {
                        margin-bottom: 0px !important;
                    }
                }
            </style>

            <nav class="navbar navbar-expand-custom navbar-mainbg">
                <a class="navbar-brand navbar-logo" href="#"><img class="my_img" src="html/assets/lte/logo.png" alt="FRAMEWORK" /></a>
                <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <div class="hori-selector">
                            <div class="left"></div>
                            <div class="right"></div>
                        </div>
                        <li class="nav-item active">
                            <a class="nav-link" href="/">home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="track">Tracking</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="our-services">Our Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact">Contact Us</a>
                        </li>

                    </ul>
                </div>
            </nav>
        </header>
    </div>

    <!-- Mobile Menu -->
    <nav aria-label="primary mobile" class="drawer d-lg-none">
        <header class="header d-lg-none d-flex justify-content-between align-items-center">
            <img class="my_img" src="html/assets/lte/logo.png" alt="FRAMEWORK">
            <button id="nav-close" class="btn p-0 stop-propagation">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </header>

        <div class="body">
            <ul class="nav-list list-unstyled mb-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.html" style="">Home </a>
                </li>


                <li id="menu-item-1" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                    <a class="nav-link dropdown-item " href="admin/shipments/tracking/view.html" <!DOCTYPE html>
                        <html lang="en">

                        <head>
                            <meta charset="UTF-8" />
                            <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                            <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
                            <meta name="csrf-token" content="Bc4iyDMhvZjJLXs1Q32PgfczTgOl5JnimEgHAAyg">
                            <link rel="profile" href="http://gmpg.org/xfn/11" />

                            <title>Tracking | Framework </title>
                            <meta name="description" content="vip courier and cargo">
                            <meta name="keywords" content="">



                            <meta property="og:url" content="en/admin/shipments/tracking/view">
                            <meta property="og:title" content="vip courier and cargo">
                            <meta property="og:description" content="vip courier and cargo">
                            <meta property="og:type" content="page">
                            <meta property="og:image" content="">


                            <meta http-equiv="x-dns-prefetch-control" content="on">
                            <meta http-equiv="X-UA-Compatible" content="IE=edge">

                            <script type="text/javascript" src="html/assets/js/jquery/jquery.js"></script>
                            <script type="text/javascript" src="html/assets/js/jquery/jquery-migrate.min.js"></script>
                            <script type="text/javascript" src="html/assets/js/plugins.js"></script>

                            <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous" />
                            <link rel="stylesheet" href="html/easyship/assets/css/style.css" />

                            <link rel="stylesheet" id="wooohoo-ilightbox-skin-css" href="html/assets/css/ilightbox/dark-skin/skin.css" type="text/css" media="all" />
                            <link rel="stylesheet" id="wooohoo-ilightbox-skin-black-css" href="html/assets/css/ilightbox/metro-black-skin/skin.css" type="text/css" media="all" />
                            <link rel="stylesheet" id="bdaia-woocommerce-css" href="html/assets/css/woocommerce.css" type="text/css" media="all" />
                            <link rel="stylesheet" href="html/assets/css/fontawesome-min.css">
                            <link rel="stylesheet" href="html/custom-assets/css/app.css">
                            <link rel="stylesheet" id="kolyoum-default-css" href="html/easyship/assets/css/post.style.css" type="text/css" media="all" />
                            <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
                            <link rel="preconnect" href="//fonts.googleapis.com/">
                            <link rel="preconnect" href="//fonts.gstatic.com/" crossorigin>
                            <link rel="dns-prefetch" href="http://fonts.googleapis.com/">
                            <link href="//fonts.gstatic.com/" crossorigin="" rel="preconnect">
                            <link rel="preload" as="script" href="//ajax.googleapis.com/ajax/libs/webfont/1/webfont.js">


                            <style type='text/css'>
                                @media only screen and (max-width: 900px) {

                                    .bd-push-menu-open aside.bd-push-menu,
                                    aside.bd-push-menu.light-skin {
                                        background: #fe4f2d;
                                        background: -webkit-linear-gradient(176deg, #cf109f, #fe4f2d);
                                        background: linear-gradient(176deg, #cf109f, #fe4f2d);
                                    }
                                }

                                @media only screen and (max-width: 900px) {
                                    div.bd-push-menu-inner::before {
                                        background-image: url("html/assets/images/dsfdsfsddfsfd.jpg") !important;
                                        background-repeat: no-repeat;
                                        background-attachment: scroll;
                                        background-position: center;
                                        background-position: center;
                                    }
                                }

                                div.bdaia-footer,
                                div.bdaia-footer.bd-footer-light {
                                    background: #111026;
                                    background: -webkit-linear-gradient(176deg, #111026, #111026);
                                    background: linear-gradient(176deg, #111026, #111026);
                                }

                                div.bdaia-footer::before {
                                    background-image: url("html/assets/images/footer-background.svg") !important;
                                    background-repeat: no-repeat;
                                    background-attachment: scroll;
                                    background-position: center top;
                                }

                                .bd-cat-10 {
                                    background: #e5b22b !important;
                                    color: #FFF !important;
                                }

                                .bd-cat-10::after {
                                    border-top-color: #e5b22b !important
                                }

                                .bd-cat-13 {
                                    background: #39a657 !important;
                                    color: #FFF !important;
                                }

                                .bd-cat-13::after {
                                    border-top-color: #39a657 !important
                                }

                                .bd-cat-8 {
                                    background: #6b45e0 !important;
                                    color: #FFF !important;
                                }

                                .bd-cat-8::after {
                                    border-top-color: #6b45e0 !important
                                }

                                .bd-cat-12 {
                                    background: #e81055 !important;
                                    color: #FFF !important;
                                }

                                .bd-cat-12::after {
                                    border-top-color: #e81055 !important
                                }

                                .bdaia-header-default .topbar:not(.topbar-light) {
                                    background: #fb8332
                                }

                                .bdaia-header-default .topbar:not(.topbar-light) {
                                    background: linear-gradient(176deg, #fb8332 0, #b31919 100%);
                                }

                                .bdaia-header-default .header-container {
                                    border-bottom: 0 none;
                                }

                                ul.bd-components>li.bd-alert-posts {
                                    padding-right: 0;
                                }

                                .bdaia-header-default .header-container .bd-container {
                                    background: url("html/assets/images/top-shadow.png") no-repeat top;
                                }

                                .bdaia-header-default .topbar.topbar-gradient .breaking-title {
                                    background-color: rgba(0, 0, 0, .75);
                                    border-radius: 2px;
                                }

                                .inner-wrapper {
                                    background-color: #FFF;
                                }

                                .article-meta-info .bd-alignleft .meta-item:last-child {
                                    margin-right: 0;
                                }

                                .article-meta-info .bd-alignright .meta-item:first-child {
                                    margin-left: 0;
                                }

                                .articles-box-dark.articles-box.articles-box-block625 .articles-box-items>li:first-child {
                                    border-bottom: 1px solid rgba(255, 255, 255, .1);
                                }

                                .articles-box.articles-box-block614 .articles-box-items>li .article-details h3 {
                                    padding: 0;
                                    font-size: 19px;
                                    line-height: 1.33;
                                    font-weight: normal;
                                }

                                .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li:hover>a,
                                .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li.current-menu-item>a,
                                .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li.current-menu-ancestor>a,
                                .bdaia-header-default #navigation.nav-boxed.mainnav-dark .primary-menu ul#menu-primary>li.current-menu-parent>a {
                                    background-color: #105EFB !important;
                                }

                                .bdaia-header-default #navigation .primary-menu ul#menu-primary>li>.bd_mega.sub-menu,
                                .bdaia-header-default #navigation .primary-menu ul#menu-primary>li>.sub-menu {
                                    border-color: #105EFB !important;
                                }

                                .bdaia-header-default #navigation.dropdown-light .primary-menu ul#menu-primary li.bd_mega_menu div.bd_mega ul.bd_mega.sub-menu li a:hover,
                                .bdaia-header-default #navigation.dropdown-light .primary-menu ul#menu-primary li ul.sub-menu li a:hover {
                                    color: #105EFB !important;
                                }
                            </style>

                            <style type="text/css" media="all">
                                :root {
                                    --brand-color: #EE6517;
                                    --dark-brand-color: #F65051;
                                    --bright-color: #FFF;
                                    --base-color: #161D40;
                                }

                                body {
                                    color: var(--base-color);
                                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Poppins, Oxygen, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", "Open Sans", Arial, sans-serif;
                                    font-size: 13px;
                                    line-height: 21px;
                                }

                                * {
                                    padding: 0;
                                    margin: 0;
                                    list-style: none;
                                    border: 0;
                                    outline: none;
                                    box-sizing: border-box;
                                }

                                a {
                                    color: var(--base-color);
                                    text-decoration: none;
                                    transition: 0.15s;
                                }

                                a:hover {
                                    color: var(--brand-color);
                                }

                                a:active,
                                a:hover {
                                    outline-width: 0;
                                }

                                div.hero section#banner.section {
                                    background: #FFFFFF !important;
                                }

                                #main-header:hover,
                                #main-header.active {
                                    -webkit-box-shadow: none !important;
                                    box-shadow: none !important;
                                }

                                #main-header .navbar .logo {
                                    -webkit-margin-end: 90px;
                                    margin-inline-end: 90px;
                                }

                                #main-header .navbar .nav-list>li {
                                    padding-inline: 0;
                                    -webkit-margin-end: 40px;
                                    margin-inline-end: 40px;
                                }

                                #main-header .navbar .nav-list>li a {
                                    font-size: 14px;
                                    font-weight: bold;
                                    letter-spacing: 0;
                                    text-transform: uppercase;
                                    color: var(--base-color) !important;
                                }

                                #main-header .navbar .nav-list>li a:hover {
                                    color: var(--brand-color) !important;
                                }

                                #main-header .navbar .nav-list .dropdown-menu.submenu,
                                #main-header .navbar .nav-list .dropdown-menu {
                                    border-radius: 0 !important;
                                    width: 230px !important;
                                    padding: 10px 0 !important;
                                    line-height: 20px !important;
                                    box-shadow: 0 15px 30px rgb(0 0 0 / 06%), 0 0 0 1px rgb(0 0 0 / 4%);
                                }

                                #main-header .navbar .nav-list .dropdown-menu.submenu a,
                                #main-header .navbar .nav-list .dropdown-menu a {
                                    display: block;
                                    margin: 0 !important;
                                    padding: 8px 20px !important;
                                    min-height: unset !important;
                                    font-size: 13px !important;
                                    text-transform: unset !important;
                                    font-weight: normal !important;
                                    color: var(--base-color) !important;
                                    max-width: 100% !important;
                                    white-space: nowrap !important;
                                    overflow: hidden !important;
                                    text-overflow: ellipsis !important;
                                }

                                #main-header .navbar .nav-list .dropdown-menu.submenu a:hover,
                                #main-header .navbar .nav-list .dropdown-menu a:hover {
                                    color: var(--brand-color) !important;
                                }

                                #main-header .navbar .nav-list li,
                                #main-header .navbar .nav-list .dropdown-item {
                                    height: unset !important;
                                    max-height: unset !important;
                                    padding-block: unset !important;
                                }

                                #main-header .navbar .nav-list ul {
                                    line-height: 20px;
                                    z-index: 1;
                                    top: unset !important;
                                    left: unset !important;
                                }

                                #main-header .navbar .nav-list ul ul {
                                    top: 0 !important;
                                    left: 100% !important;
                                    margin-top: -10px !important;
                                }

                                #main-header .navbar .nav-list li svg {
                                    display: none !important;
                                }

                                #banner .btn {
                                    padding: 22px 40px;
                                    height: unset;
                                    border-radius: 10px !important;
                                    box-shadow: none !important;
                                    font-size: 18px;
                                    font-weight: 600;
                                    margin: 30px 0 0 0;
                                    font-family: 'Poppins';
                                    text-transform: unset !important;
                                }

                                .section .intro .heading {
                                    font-family: 'Poppins';
                                    font-weight: 600;
                                    letter-spacing: -2px;
                                }

                                @media only screen and (min-width: 75rem) {
                                    #banner .container {
                                        padding: 145px 0;
                                    }
                                }

                                @media (min-width: 62rem) {
                                    section#banner div.wrapper {
                                        height: 100% !important;
                                        display: flex !important;
                                        align-items: center !important;
                                        justify-content: center !important;
                                    }

                                    section#banner div.wrapper img {
                                        max-width: 700px !important;
                                        max-height: unset !important;
                                        margin-left: auto !important;
                                    }

                                    #good-hands .intro {
                                        text-align: unset !important;
                                    }

                                    section.section .intro h2.heading {
                                        max-width: 700px !important;
                                        margin-left: auto !important;
                                        margin-right: auto !important;
                                        margin-top: unset !important;
                                    }

                                    section.section {}


                                }


                                .bdaia-post-content blockquote {
                                    padding: 0 1em !important;
                                    margin: 40px 0 38px 0 !important;
                                    border-left: .25em solid !important;
                                    overflow-wrap: break-word !important;
                                }

                                .item img {
                                    height: 100%;
                                    width: 100%;
                                    object-fit: cover;
                                    object-position: 60% 52%;
                                }

                                .swiper-pagination-bullet {
                                    background: transparent;
                                }

                                .swiper-pagination-bullet-active .path {
                                    display: inline-block !important;
                                    stroke-dasharray: 1000;
                                    stroke-dashoffset: 0;
                                    animation: dash linear 120s;
                                    animation-iteration-count: unset;
                                }

                                .path {
                                    display: none;
                                }

                                @keyframes dash {
                                    from {
                                        stroke-dashoffset: 1000;
                                    }

                                    to {
                                        stroke-dashoffset: 0;
                                    }
                                }

                                .swiper-pagination {
                                    display: flex;
                                    justify-content: center;
                                    align-items: center;
                                    gap: 24px;
                                    bottom: 50px !important;
                                }

                                section.banner_sec {
                                    height: 400px;
                                    position: relative;
                                }

                                .banner_sec div#shipments-tracking {
                                    position: absolute;
                                    z-index: 4;
                                    top: 64px;
                                    left: 54px;
                                    width: 350px;
                                    margin: 0;
                                    border: 6px solid rgba(255, 255, 255, .1);
                                    background: #1d2f3c;
                                }

                                .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget .bdaia-mc4wp-bform-p {
                                    color: #FFF;
                                }

                                .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget .bdaia-mc4wp-bform-p2 {
                                    color: #72818d;
                                }

                                .banner_sec .mc4wp-form-fields {
                                    padding-top: 15px;
                                    display: grid !important;
                                    gap: 10px !important;
                                }

                                .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget .mc4wp-form-fields p:first-child {
                                    width: 100%;
                                    margin-bottom: 0;
                                }

                                .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget .mc4wp-form-fields {
                                    display: inline-block;
                                    width: 100%;
                                    max-width: 100%;
                                }

                                .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget .mc4wp-form-fields p {
                                    width: 100%;
                                }

                                .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget input[type=submit] {
                                    min-width: 164px;
                                    width: 100%;
                                }

                                @media (max-width: 600px) {
                                    .cs_top_services_box {
                                        margin-bottom: 20px;
                                        width: 100%;
                                    }

                                    .cs_about_img.wow.fadeInUp img {
                                        margin-top: 30px;
                                    }

                                    .cs_about_img {
                                        padding-left: 0;
                                    }

                                    .cs_about_content h1 {
                                        font-size: 25px;
                                    }

                                    .cs_about_wrapper {
                                        padding: 10px 0 0;
                                    }

                                    .col-sm-4.col-md-4.col-lg-4.mt-40.wow.fadeInRight {
                                        margin-bottom: 20px;
                                    }

                                    .col-sm-4.col-md-4.col-lg-4.wow.fadeInLeft {
                                        margin-bottom: 20px;
                                    }

                                    .col-sm-4.col-md-4.col-lg-4.wow.fadeInRight {
                                        margin-bottom: 20px;
                                    }

                                    .banner_sec div#shipments-tracking {
                                        position: absolute;
                                        z-index: 4;
                                        top: 45px;
                                        left: 45px;
                                        width: 300px;
                                        margin: 0;
                                        border: 6px solid rgba(255, 255, 255, .1);
                                        background: #1d2f3cb5;
                                    }

                                    .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget .bdaia-mc4wp-bform-p {
                                        color: #FFF;
                                        font-size: 20px;
                                    }

                                    .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget .bdaia-mc4wp-bform-p2 {
                                        color: #fff;
                                        font-size: 14px;
                                    }

                                    .banner_sec .widget.bdaia-widget.widget_mc4wp_form_widget form input {
                                        min-height: 40px;
                                        text-align: center;
                                    }

                                    .banner_sec svg.fp-arc-loader {
                                        height: 20px;
                                        width: 20px;
                                    }

                                    .swiper-pagination {
                                        display: flex;
                                        justify-content: center;
                                        align-items: center;
                                        gap: 24px;
                                        bottom: 30px !important;
                                    }
                                }
                            </style>







                        </head>

                        <body class="home page-template-default page wp-embed-responsive has-lazy-load" itemscope="itemscope" itemtype="//schema.org/WebPage">


                            <div class="bdaia-header-default">
                                <header id="main-header" class="active light_style">

                                    <nav id="navigation" class="navbar dropdown-light" aria-label="primary">
                                        <div class="container">
                                            <div class="d-flex justify-content-center align-items-center">
                                                <div class="logo site--logo">
                                                    <a href="en.html" rel="home" title="FRAMEWORK">
                                                        <img class="my_img" src="html/assets/lte/logo.png" alt="FRAMEWORK" />
                                                    </a>
                                                </div>


                                                <ul class="nav-list close-web-menu list-unstyled mb-0">
                                                    <li class="nav-item">
                                                        <a class="nav-link" href="en-2" style="">Home </a>
                                                    </li>


                                                    <li id="menu-item-1" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                                        <a class="nav-link dropdown-item " href="tacking">Tracking</a>
                                                    </li>

                                                    <li id="menu-item-3" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                                        <a class="nav-link dropdown-item " href="calculator">Shipment Calculator</a>
                                                    </li>

                                                    <li id="menu-item-5" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                                        <a class="nav-link dropdown-item " href="about-2">About Us</a>
                                                    </li>
                                                    <li id="menu-item-5" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                                        <a class="nav-link dropdown-item " href="contact">Contact Us</a>
                                                    </li>
                                                </ul>


                                                <style type="text/css" media="all">
                                                    @media (max-width: 1000px) {
                                                        .close-web-menu {
                                                            display: none !important;
                                                        }
                                                    }
                                                </style>



                                            </div>

                                            <div class="mobile-items">
                                                <button id="nav-open" class="btn btn-sm px-3 bars d-lg-none stop-propagation" aria-label="navbar toggle" style="">
                                                    <i data-feather="menu"></i>
                                                </button>
                                                <!-- dropdowns -->

                                                <ul class="nav-components bd-components">
                                                    <li class="components-item">
                                                        <a href="en/admin/dashboard.html">
                                                            <span class="bdaia-ns-btn mr-3" style="display: inline-block; height: 50px; line-height: 50px">
                                                                <svg xmlns="http://www.w3.org/2000/svg" height="27" viewBox="0 0 24 24" style="width:auto">
                                                                    <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM7.07 18.28c.43-.9 3.05-1.78 4.93-1.78s4.51.88 4.93 1.78C15.57 19.36 13.86 20 12 20s-3.57-.64-4.93-1.72zm11.29-1.45c-1.43-1.74-4.9-2.33-6.36-2.33s-4.93.59-6.36 2.33C4.62 15.49 4 13.82 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8c0 1.82-.62 3.49-1.64 4.83zM12 6c-1.94 0-3.5 1.56-3.5 3.5S10.06 13 12 13s3.5-1.56 3.5-3.5S13.94 6 12 6zm0 5c-.83 0-1.5-.67-1.5-1.5S11.17 8 12 8s1.5.67 1.5 1.5S12.83 11 12 11z" />
                                                                </svg>
                                                            </span>
                                                        </a>
                                                    </li>

                                                    <!-- Start:: Header Search -->
                                                    <li class="bd-search-bar components-item">
                                                        <span class="bdaia-ns-btn mr-3" style="display: inline-block; height: 50px; line-height: 50px">
                                                            <svg style="width:auto" height="22" viewBox="0 0 959.36 820.05" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill="currentColor" d="m959.24 34.19c0-20.57-13.59-34.19-34.13-34.19h-889.94c-21.95 0-35.17 13.23-35.17 35.18q0 114.24 0 228.48 0 202.48 0 405c0 21.21 13.47 34.59 34.72 34.6q91.5 0 183 .1c4.33 0 5.71-1 5.64-5.52q-.41-25.74 0-51.49c.08-4.92-1-6.48-6.26-6.45-49 .22-98 .14-147 .11-7.7 0-6.86 1-6.86-7q0-185.73-.11-371.47c0-4.89 1-6.44 6.21-6.41 38.66.25 77.32 0 116 .25 4.91 0 6.08-1.45 6-6.17q-.4-25.74 0-51.49c.08-4.69-1.35-5.81-5.89-5.79-38.83.17-77.66 0-116.49.19-4.48 0-5.87-1-5.85-5.73.2-38.83.11-77.66.11-116.49 0-6.62 0-6.63 6.77-6.63h260.51q279.74 0 559.47-.1c4.66 0 6.18.94 6.15 5.94q-.33 58.74 0 117.49c0 4.45-1.21 5.54-5.58 5.52-39.16-.17-78.33 0-117.49-.18-3.87 0-5.18 1-5.13 5q.33 26.24 0 52.49c-.06 4.46 1 6 5.74 5.94 20.83-.27 41.66-.12 62.5-.12 18.33 0 36.66.12 55-.09 4.06 0 5.41 1.3 4.89 5.11a27.23 27.23 0 0 0 0 3.5q0 200.73-.11 401.47c0 4.76 1.15 6.21 6 6.12 17.16-.3 34.33-.25 51.49 0 4.4.06 6-.87 5.94-5.69q-.2-315.75-.13-631.48z" />
                                                                <path fill="currentColor" d="m707.52 631.15c-2.35-2.34-3.68-3.9-1-7.35 50-65.7 69.2-139.55 56.86-221.16-8.92-59-34.49-110.2-75.82-153.2-56.56-58.78-126.14-87.73-203.69-89.44-26.34-.07-54 3.42-76.7 9.45q-87.28 23.2-146.17 91.74c-40.19 47-62.55 101.6-68 163.09a272.35 272.35 0 0 0 4.71 79.43c16.18 78 57.39 139.51 123.5 183.53 61.71 41.08 129.93 55.28 203.29 44.15 47.88-7.27 90.85-26.13 129.39-55.31 6.13-4.64 4.72-5 10.25.56q70.54 70.49 141 141.11c3.2 3.21 4.75 3 7.74-.12 11.83-12.2 24-24.12 36-36.13 4.52-4.52 4.52-4.52 0-9q-70.64-70.69-141.36-141.35zm-3.34-179.94c-1.83 121-101.88 221-224.65 221-123.4 0-226.67-102.46-224.47-228.69 2.13-121.15 102.52-221.25 224.66-220.27 123.08-1.05 226.38 101.75 224.46 227.96z" />
                                                                <path fill="currentColor" d="m154.93 96q-27.45.18-54.9 0c-3 0-4.09.9-4.07 4q.17 27.69 0 55.4c0 3.14 1.18 4 4.12 3.94 9.15-.13 18.3 0 27.45 0s18.31-.11 27.45.06c3.23.06 4.36-.92 4.34-4.24q-.19-27.45 0-54.91c.01-3.47-1.22-4.32-4.39-4.25z" />
                                                                <path fill="currentColor" d="m196 159.29c18.31-.1 36.61-.14 54.92 0 3.73 0 4.43-1.45 4.38-4.72-.16-9-.06-18-.06-27 0-9.15-.13-18.3.06-27.45.06-3.32-1.09-4.28-4.32-4.26q-27.47.19-54.92 0c-2.93 0-4.14.77-4.12 3.93q.18 27.71 0 55.41c-.01 3.18 1.06 4.11 4.06 4.09z" />
                                                                <path fill="currentColor" d="m292.38 159.3c9-.15 18-.05 27-.05 9.16 0 18.32-.08 27.48.05 3 0 4.52-.52 4.49-4.06-.15-18.48-.11-37 0-55.44 0-2.73-.76-3.86-3.67-3.84q-28 .14-55.94 0c-2.86 0-3.74 1-3.72 3.8.08 18.48.12 37 0 55.44-.11 3.49 1.28 4.16 4.36 4.1z" />
                                                                <path fill="currentColor" d="m367.25 447.61c0-30.15-.05-60.29.06-90.44 0-3.65-.59-5.32-4.87-5.26-18 .24-36 .18-54 0-3.52 0-4.54 1.09-4.53 4.57q.12 91.19 0 182.37c0 3.64 1.27 4.46 4.63 4.43 17.82-.13 35.65-.18 53.47 0 4.14 0 5.34-1.11 5.31-5.29-.15-30.09-.07-60.23-.07-90.38z" />
                                                                <path fill="currentColor" d="m596.74 351.92c-3.72 0-4.82 1-4.82 4.78q.18 90.93 0 181.88c0 3.81 1.22 4.77 4.88 4.74 17.65-.17 35.31-.22 53 0 4.43.06 5.61-1.19 5.58-5.59-.19-30-.1-60-.1-89.94 0-30.15-.07-60.3.08-90.44 0-3.94-.73-5.54-5.13-5.48-17.85.28-35.67.23-53.49.05z" />
                                                                <path fill="currentColor" d="m463.25 431.91c0-25-.09-50 .08-74.93 0-4-1.13-5.1-5.08-5.06q-26.72.3-53.45 0c-3.65 0-4.88.92-4.87 4.74q.18 74.93 0 149.86c0 3.75 1.12 4.82 4.83 4.78 17.65-.17 35.3-.2 52.95 0 4.3.06 5.7-1 5.66-5.51-.23-24.59-.12-49.24-.12-73.88z" />
                                                                <path fill="currentColor" d="m559.25 431.59c0-24.82-.07-49.63.06-74.45 0-3.68-.64-5.3-4.88-5.24-18 .24-36 .19-54 0-3.53 0-4.53 1.07-4.53 4.55q.15 75.21 0 150.4c0 3.65 1.3 4.44 4.64 4.42 17.82-.13 35.65-.18 53.47 0 4.15.06 5.34-1.13 5.3-5.3-.15-24.74-.06-49.56-.06-74.38z" />
                                                            </svg>
                                                        </span>
                                                        <div class="bdaia-ns-wrap components-sub-menu mr-3" style="opacity: 0; display: none; transform: translateY(0px);">
                                                            <div class="bdaia-ns-content">
                                                                <div class="bdaia-ns-inner">
                                                                    <form class="form" action="//vipcourierandcargo.com/en/admin/shipments/tracking" method="GET">
                                                                        <input type="text" class="bbd-search-field search-live" id="code" name="code" placeholder="Enter your tracking code" autocomplete="off" />

                                                                        <button type="submit" class="bbd-search-btn"><span class="bdaia-io bdaia-io-ion-ios-search-strong"></span></button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <!-- END:: Header Search -->

                                                </ul>


                                                <div class="dropdowns">
                                                    <div class="position-relative">
                                                        <span class="" data-toggle="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="">

                                                            <svg height="22" viewBox="0 0 22 22" style="width:auto" xmlns="http://www.w3.org/2000/svg">
                                                                <g fill="currentColor" transform="">
                                                                    <path d="m11 22c-6.06517241 0-11-4.9348276-11-11 0-6.06517241 4.93482759-11 11-11 6.0651724 0 11 4.93482759 11 11 0 6.0651724-4.9348276 11-11 11zm0-21.24137931c-5.64717241 0-10.24137931 4.5942069-10.24137931 10.24137931 0 5.6471724 4.5942069 10.2413793 10.24137931 10.2413793 5.6471724 0 10.2413793-4.5942069 10.2413793-10.2413793 0-5.64717241-4.5942069-10.24137931-10.2413793-10.24137931z" />
                                                                    <path d="m11 22c-3.40317241 0-6.17289655-4.9348276-6.17289655-11 0-6.06517241 2.76972414-11 6.17289655-11 3.4031724 0 6.1728966 4.93482759 6.1728966 11 0 6.0651724-2.7697242 11-6.1728966 11zm0-21.24137931c-2.98593103 0-5.41427586 4.5942069-5.41427586 10.24137931 0 5.6471724 2.42834483 10.2413793 5.41427586 10.2413793 2.985931 0 5.4142759-4.5942069 5.4142759-10.2413793 0-5.64717241-2.4283449-10.24137931-5.4142759-10.24137931z" />
                                                                    <path d="m21.6206897 11.3793103h-21.24137935c-.20937932 0-.37931035-.169931-.37931035-.3793103s.16993103-.3793103.37931035-.3793103h21.24137935c.2093793 0 .3793103.169931.3793103.3793103s-.169931.3793103-.3793103.3793103z" />
                                                                    <path d="m20.1944828 6.06896552h-18.38896556c-.20937931 0-.37931034-.16993104-.37931034-.37931035s.16993103-.37931034.37931034-.37931034h18.38896556c.2093793 0 .3793103.16993103.3793103.37931034s-.169931.37931035-.3793103.37931035z" />
                                                                    <path d="m20.1944828 16.6896552h-18.38896556c-.20937931 0-.37931034-.1699311-.37931034-.3793104s.16993103-.3793103.37931034-.3793103h18.38896556c.2093793 0 .3793103.169931.3793103.3793103s-.169931.3793104-.3793103.3793104z" />
                                                                    <path d="m11 22c-.2093793 0-.3793103-.169931-.3793103-.3793103v-21.24137935c0-.20937932.169931-.37931035.3793103-.37931035s.3793103.16993103.3793103.37931035v21.24137935c0 .2093793-.169931.3793103-.3793103.3793103z" />
                                                                </g>
                                                            </svg>

                                                            &nbsp;

                                                            English
                                                        </span>
                                                        <div class="dropdown-menu" style="margin-top: 15px">
                                                            <a class="dropdown-item active" href="en/admin/shipments/tracking/view">English</a>
                                                            <a class="dropdown-item" href="ar/admin/shipments/tracking/view">ا</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </nav>
                                </header>
                            </div>

                            <!-- Mobile Menu -->
                            <nav aria-label="primary mobile" class="drawer d-lg-none">
                                <header class="header d-lg-none d-flex justify-content-between align-items-center">
                                    <img class="my_img" src="html/assets/lte/logo.png" alt="FRAMEWORK" />
                                    <button id="nav-close" class="btn p-0 stop-propagation">
                                        <i data-feather="x"></i>
                                    </button>
                                </header>

                                <div class="body">
                                    <ul class="nav-list list-unstyled mb-0">
                                        <li class="nav-item">
                                            <a class="nav-link" href="index.html" style="">Home </a>
                                        </li>


                                        <li id="menu-item-1" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                            <a class="nav-link dropdown-item " href="track">Tracking</a>
                                        </li>

                                        <li id="menu-item-3" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                            <a class="nav-link dropdown-item " href="cal.html">Shipment Calculator</a>
                                        </li>

                                        <li id="menu-item-5" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                            <a class="nav-link dropdown-item " href="about">About Us</a>
                                        </li>
                                        <li id="menu-item-5" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                                            <a class="nav-link dropdown-item " href="contact-2">Contact Us</a>
                                        </li>
                                    </ul>
                                </div>
                            </nav>









                            <div class="bd-content-wrap" style="transform: none;">
                                <div class="cfix"></div>
                                <div class="clearfix"></div>




                                <!-- .slider-area -->
                                <div class="bd-container-post entry-content-only" style="transform: none;">
                                    <div class="bd-row" style="transform: none;">
                                        <div id="shipments-tracking-page">
                                            <div id="shipments-tracking" class="widget bdaia-widget widget_mc4wp_form_widget">
                                                <div class="widget-inner">
                                                    <form class="form" action="//vipcourierandcargo.com/en/admin/shipments/tracking" method="GET">
                                                        <div class="bdaia-mc4wp-form-icon">
                                                            <span class="bdaia-io text-primary" style="line-height: 0">
                                                                <svg style="width:auto" height="58px" viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg">
                                                                    <path fill="currentColor" d="m57.123 31.247v13.63h-12.247v-13.63zm3.925-4h27.552l-8.625-15.99h-20.155zm-18.868-15.99h-20.159l-8.621 15.99h27.551zm2.783 15.99h12.073l-1.229-15.99h-9.615zm2.03 44.992a25.612 25.612 0 0 1 .486-4.979h-19.888a5.133 5.133 0 0 0 -5.127 5.127v1.432a5.133 5.133 0 0 0 5.127 5.127h20.3a25.46 25.46 0 0 1 -.897-6.707zm7.393 17.875a25.231 25.231 0 0 1 -5.032-7.169h-21.763a9.137 9.137 0 0 1 -9.127-9.127v-1.431a9.137 9.137 0 0 1 9.127-9.127h21.04a25.28 25.28 0 0 1 41.507-8.9c.214.214.418.434.623.654v-23.767h-29.638v15.63a2 2 0 0 1 -2 2h-16.247a2 2 0 0 1 -2-2v-15.63h-29.638v60.185h44.58c-.49-.421-.97-.856-1.432-1.318zm10.36-23.922a2.08 2.08 0 0 0 -2.08 2.08v7.933a2.08 2.08 0 1 0 4.16 0v-7.932a2.08 2.08 0 0 0 -2.08-2.08zm9.6 2.08v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm7.516 0v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm-17.112-2.08a2.08 2.08 0 0 0 -2.08 2.08v7.933a2.08 2.08 0 1 0 4.16 0v-7.932a2.08 2.08 0 0 0 -2.084-2.08zm9.6 2.08v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm7.516 0v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm11.673 3.967a21.292 21.292 0 1 1 -21.3-21.292 21.292 21.292 0 0 1 21.292 21.292zm-6.716 0a14.576 14.576 0 1 0 -14.584 14.576 14.576 14.576 0 0 0 14.576-14.576zm29.934 37.387a6.864 6.864 0 0 1 -6.974 7.1 8.6 8.6 0 0 1 -6.214-2.785l-14.663-15.651a1 1 0 0 1 .023-1.391l.977-.977-3.057-3.057a25.493 25.493 0 0 0 6.036-6.044l3.061 3.061.977-.977a1 1 0 0 1 1.391-.023l15.651 14.656a8.624 8.624 0 0 1 2.784 6.088zm-4 .066a4.608 4.608 0 0 0 -1.52-3.233l-13.537-12.672-3.89 3.888 12.671 13.532a4.586 4.586 0 0 0 3.294 1.52 2.868 2.868 0 0 0 2.974-3.034z" />
                                                                </svg>
                                                            </span>
                                                        </div>

                                                        <p class="bdaia-mc4wp-bform-p bd1-font">
                                                            Tracking Shipment
                                                        </p>

                                                        <p class="bdaia-mc4wp-bform-p2 bd2-font">
                                                            Enter your tracking code
                                                        </p>

                                                        <div class="mc4wp-form-fields">
                                                            <p>
                                                                <label>
                                                                    Enter your tracking code
                                                                </label>

                                                                <input type="text" name="code" placeholder="AWB72704">
                                                            </p>
                                                            <p>
                                                                <input type="submit" class="btn btn-submit submit" value="Search">
                                                            </p>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div><!--#shipments-tracking-page -->
                                    </div>
                                </div>




                            </div>












                            <div class="gotop" title="Go Top"><span class="bdaia-io bdaia-io-ion-android-arrow-up"></span></div>




                            <script>
                                WebFontConfig = {
                                    google: {
                                        families: ["Poppins:regular,500,600,700:latin", "Roboto:100,300,400,500,700,900:latin", "Open+Sans:400,600,700,800:latin"],
                                    },
                                };
                                (function() {
                                    var wf = document.createElement("script");
                                    wf.src = "//ajax.googleapis.com/ajax/libs/webfont/1/webfont.js";
                                    wf.type = "text/javascript";
                                    wf.async = "true";
                                    var s = document.getElementsByTagName("script")[0];
                                    s.parentNode.insertBefore(wf, s);
                                })();
                            </script>
                            <script type="text/javascript" src="html/assets/js/functions.js"></script>
                            <script type="text/javascript" src="html/assets/js/sliders.js"></script>
                            <script type="text/javascript" src="html/custom-assets/js/app.js"></script>

                            <!-- <script src="//cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
                            <script src="//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
                            <script src="//cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
                            <script src="//cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
                            <script>
                                var swiper = new Swiper(".mySwiper", {
                                    speed: 1000,
                                    loop: true,
                                    autoplay: {
                                        delay: 4000,
                                        waitForTransition: true,
                                        disableOnInteraction: false,
                                    },
                                    flipEffect: {
                                        rotate: 30,
                                        slideShadows: false,
                                    },
                                    // If we need pagination
                                    pagination: {
                                        el: '.swiper-pagination',
                                        clickable: true,
                                        renderBullet: function(index, className) {
                                            return '<span class="' + className + '">' + '<svg class="fp-arc-loader" width="40" height="40" viewBox="0 0 16 16">' +
                                                '<circle class="path" cx="8" cy="8" r="5.5" fill="none" transform="rotate(-90 8 8)" stroke="#FFF"' +
                                                'stroke-opacity="1" stroke-width="1.5px"></circle>' +
                                                '<circle cx="8" cy="8" r="3" fill="#FFF"></circle>' +
                                                '</svg></span>';
                                        },

                                    },

                                    // Navigation arrows
                                    navigation: false,
                                });
                            </script>
                            <script>
                                feather.replace();
                            </script>

                            <script async src="//unpkg.com/typer-dot-js@0.1.0/typer.js"></script>
                            <script src="html/easyship/assets/js/main.js"></script>







                        </body>

                        </html>>Tracking
                    </a>
                </li>

                <li id="menu-item-3" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                    <a class="nav-link dropdown-item " href="calculator.html">Shipment Calculator</a>
                </li>

                <li id="menu-item-5" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                    <a class="nav-link dropdown-item " href="about-2">Sample Page</a>
                </li>

                <li id="menu-item-10" class="nav-item menu-item-has-children dropdown menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                    <a class="nav-link dropdown-item dropdown-toggle" href="blog.html" style="" data-toggle="dropdown">News</a>
                    <ul class="dropdown-menu  ">

                        <li id="menu-item-4" class="nav-item  menu-item menu-item-type-custom menu-item-object-custom menu-parent-item menu-item--parent bd_menu_item">
                            <a class="nav-link dropdown-item " href="general.html">General</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>










    <div class="bd-content-wrap">
        <div class="cfix"></div>

        <div class="bd-container entry-content-only">
            <div class="vc_row wpb_row vc_row-fluid">
                <div class="full-width theia_stickys is-fixeds" style="clear: both;">
                    <div class="bd-container">
                        <section class="banner_sec">
                            <div class="row">
                                <div class="col-lg-4 col-md-6">
                                    <aside id="footer_sidebar_2" class="sidebar-footer">
                                        <section class="">
                                            <div id="shipments-tracking" class="widget bdaia-widget widget_mc4wp_form_widget" style="">
                                                <div class="widget-inner">
                                                    <form class="form" action="track" method="POST">
                                                        <input type="hidden" name="_token" value="TGvpPCLBaCZ7D12Nel9HY4Hc2i9nhe7tWgGifp2x">
                                                        <div class="bdaia-mc4wp-form-icon">
                                                            <span class="bdaia-io text-primary" style="line-height: 0">
                                                                <svg style="width:auto; " height="58px" viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg">
                                                                    <path fill="currentColor" d="m57.123 31.247v13.63h-12.247v-13.63zm3.925-4h27.552l-8.625-15.99h-20.155zm-18.868-15.99h-20.159l-8.621 15.99h27.551zm2.783 15.99h12.073l-1.229-15.99h-9.615zm2.03 44.992a25.612 25.612 0 0 1 .486-4.979h-19.888a5.133 5.133 0 0 0 -5.127 5.127v1.432a5.133 5.133 0 0 0 5.127 5.127h20.3a25.46 25.46 0 0 1 -.897-6.707zm7.393 17.875a25.231 25.231 0 0 1 -5.032-7.169h-21.763a9.137 9.137 0 0 1 -9.127-9.127v-1.431a9.137 9.137 0 0 1 9.127-9.127h21.04a25.28 25.28 0 0 1 41.507-8.9c.214.214.418.434.623.654v-23.767h-29.638v15.63a2 2 0 0 1 -2 2h-16.247a2 2 0 0 1 -2-2v-15.63h-29.638v60.185h44.58c-.49-.421-.97-.856-1.432-1.318zm10.36-23.922a2.08 2.08 0 0 0 -2.08 2.08v7.933a2.08 2.08 0 1 0 4.16 0v-7.932a2.08 2.08 0 0 0 -2.08-2.08zm9.6 2.08v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm7.516 0v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm-17.112-2.08a2.08 2.08 0 0 0 -2.08 2.08v7.933a2.08 2.08 0 1 0 4.16 0v-7.932a2.08 2.08 0 0 0 -2.084-2.08zm9.6 2.08v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm7.516 0v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm11.673 3.967a21.292 21.292 0 1 1 -21.3-21.292 21.292 21.292 0 0 1 21.292 21.292zm-6.716 0a14.576 14.576 0 1 0 -14.584 14.576 14.576 14.576 0 0 0 14.576-14.576zm29.934 37.387a6.864 6.864 0 0 1 -6.974 7.1 8.6 8.6 0 0 1 -6.214-2.785l-14.663-15.651a1 1 0 0 1 .023-1.391l.977-.977-3.057-3.057a25.493 25.493 0 0 0 6.036-6.044l3.061 3.061.977-.977a1 1 0 0 1 1.391-.023l15.651 14.656a8.624 8.624 0 0 1 2.784 6.088zm-4 .066a4.608 4.608 0 0 0 -1.52-3.233l-13.537-12.672-3.89 3.888 12.671 13.532a4.586 4.586 0 0 0 3.294 1.52 2.868 2.868 0 0 0 2.974-3.034z"></path>
                                                                </svg>
                                                            </span>
                                                        </div>

                                                        <p class="bdaia-mc4wp-bform-p bd1-font" style="">
                                                            Tracking Shipment
                                                        </p>

                                                        <p class="bdaia-mc4wp-bform-p2 bd2-font" style="">
                                                            Enter your tracking code
                                                        </p>

                                                        <div class="mc4wp-form-fields">
                                                            <p>
                                                                <label style="">
                                                                    Enter your tracking code
                                                                </label>

                                                                <input type="text" name="code" placeholder="AWB72704">
                                                            </p>
                                                            <p>
                                                                <input type="submit" class="btn btn-submit submit" value="Search" style=" ">
                                                            </p>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </section>
                                    </aside>
                                </div>
                            </div>

                            <div class="banner_slider swiper mySwiper">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide item">
                                        <img class="img-fluid" src="html/assets/b_1.jpg" alt="" />
                                    </div>
                                    <div class="swiper-slide item">
                                        <img class="img-fluid" src="html/assets/b_2.jpg" alt="" />
                                    </div>
                                    <div class="swiper-slide item">
                                        <img class="img-fluid" src="html/assets/b_3.jpg" alt="" />
                                    </div>
                                </div>
                                <div class="swiper-pagination">

                                </div>
                            </div>
                        </section>



                        <!-- ====================banner section end====================== -->
                    </div>
                </div>




                <div class="banner_bottom_section">
                    <div class="container">
                        <div class="text-center hgroup mt-40">
                            <h1>Welcome to <br>
                                VIP Courier & Cargo Courier Services</h1>

                        </div>


                        <div class="row column-info block-content">
                            <div class="col-sm-4 col-md-4 col-lg-4 wow fadeInLeft" data-wow-delay="3.3s" style="visibility: visible; animation-delay: 3.3s; animation-name: fadeInLeft;">
                                <a href="#"><img src="html/assets/Freight-Forwarding-Services.jpg" class="img-thumbnail" alt="Freight Forwarding Services"></a>
                                <span></span>
                                <h3>Freight Forwarding Services</h3>
                                <p class="text-center">We as a daily air freight shipper to all major destinations, we can take care of your unaccompanied baggage.</p>

                            </div>
                            <div class="col-sm-4 col-md-4 col-lg-4 wow fadeInRight" data-wow-delay="3.3s" style="visibility: visible; animation-delay: 3.3s; animation-name: fadeInRight;">
                                <a href="#"><img src="html/assets/Warehousing-Services.jpg" class="img-thumbnail" alt="Warehousing Services"></a>
                                <span></span>
                                <h3>Warehousing Services</h3>
                                <p class="text-center">We have an excellent track record for successful warehouse design, implementation and operation for both dedicated and multi-user facilities. </p>

                            </div>


                            <!-- <div class="col-sm-4 col-md-4 col-lg-4 wow zoomInUp" data-wow-delay="0.3s">
                		<a href="Car-Carrier-Services.asp"><img src="images/our-services/CAR-CARRIER-SERVICES.jpg" class="img-thumbnail" alt="CAR CARRIER SERVICES"></a>
	                    <span></span>
	                    <h3>Car Carrier Services</h3>
                        <p class="text-center">Door-to-Door Service - The Car Carrier Transporters offer the most convenient service. Your vehicle will be picked up at your home or office and delivered right to your new home.</p>
	                    <a class="btn btn-default btn-sm" href="Car-Carrier-Services.asp">READ MORE</a>
	                </div>-->


                            <div class="col-sm-4 col-md-4 col-lg-4 wow fadeInLeft" data-wow-delay="3.3s" style="visibility: visible; animation-delay: 3.3s; animation-name: fadeInLeft;">
                                <a href="#"><img src="html/assets/CARGO-SERVICES.jpg" class="img-thumbnail" alt="CARGO SERVICES"></a>
                                <span></span>
                                <h3>Cargo Services</h3>
                                <p class="text-center">Cargo Services Production and sales activities are completed when the products are delivered to the buyers. To meet diversifying user needs and to respond to these needs . </p>

                            </div>


                            <div class="col-sm-4 col-md-4 col-lg-4 mt-40 wow fadeInRight" data-wow-delay="3.3s" style="visibility: visible; animation-delay: 3.3s; animation-name: fadeInRight;">
                                <a href="#"><img src="html/assets/Door-Door-Delivery-Services.jpg" class="img-thumbnail" alt="Door Door Delivery Services"></a>
                                <span></span>
                                <h3>Door Door Delivery Services</h3>
                                <p class="text-center">We offer fast and efficient door to door delivery services to our clients. Our road transport department is capable of moving your consignments. </p>

                            </div>


                            <div class="col-sm-4 col-md-4 col-lg-4 mt-40 wow zoomInUp" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: zoomInUp;">
                                <a href="#"><img src="html/assets/TRANSPORTATION-SERVICES.jpg" class="img-thumbnail" alt="TRANSPORTATION SERVICES"></a>
                                <span></span>
                                <h3>Transportation Services</h3>
                                <p class="text-center">Our organization holds expertise in offering cargo and freight transport services that differs from case to case and depends on the customer's priorities. </p>

                            </div>
                        </div>
                    </div>
                </div>


                <div class="cs_top_services_wrapper mt-0">
                    <div class="container">
                        <div class="row wow fadeIn bounceInUp" data-wow-duration="1.3s" style="visibility: visible; animation-duration: 1.3s; animation-name: bounceInUp;">
                            <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                                <div class="cs_top_services_box">
                                    <div class="cs_top_services_icon">
                                        <div class="cs_top_services_icon">
                                            <img src="html/assets/export-logistics.svg" alt="Export Logistics" title="Export Logistics">
                                        </div>
                                        <div class="cs_top_services_icon">
                                            <p>Export Logistics</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                                <div class="cs_top_services_box">
                                    <div class="cs_top_services_icon">
                                        <div class="cs_top_services_icon">
                                            <img src="html/assets/import-logistic.svg" alt="Import Logistics" title="Import Logistics">
                                        </div>
                                        <div class="cs_top_services_icon">
                                            <p>Import Logistics</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                                <div class="cs_top_services_box">
                                    <div class="cs_top_services_icon">
                                        <div class="cs_top_services_icon">
                                            <img src="html/assets/product-safty.svg" alt="Product Safety" title="Product Safety">
                                        </div>
                                        <div class="cs_top_services_icon">
                                            <p>Product Safety</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                                <div class="cs_top_services_box">
                                    <div class="cs_top_services_icon">
                                        <div class="cs_top_services_icon">
                                            <img src="html/assets/fastest-delivery.svg" alt="Fastest Delivery" title="Fastest Delivery">
                                        </div>
                                        <div class="cs_top_services_icon">
                                            <p>Fastest Delivery</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                                <div class="cs_top_services_box">
                                    <div class="cs_top_services_icon">
                                        <div class="cs_top_services_icon">
                                            <img src="html/assets/24x7-service.svg" alt="24 X 7 Service" title="24 X 7 Service">
                                        </div>
                                        <div class="cs_top_services_icon">
                                            <p>24 X 7 Service</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                                <div class="cs_top_services_box">
                                    <div class="cs_top_services_icon">
                                        <div class="cs_top_services_icon">
                                            <img src="html/assets/help_center.svg" alt="" title="">
                                        </div>
                                        <div class="cs_top_services_icon">
                                            <p>Help Center</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="cs_about_wrapper">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12 order-lg-1 order-md-1 order-sm-2 order-2">
                                <div class="cs_about_img wow fadeInUp" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                                    <img src="html/assets/we-always-use-best.png" class="img-fluid" alt="we-always-use-best">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12 order-lg-1 order-md-2 order-sm-1 order-1">
                                <div class="cs_about_content" data-wow-duration="0.8s" style="visibility: visible; animation-duration: 0.8s; animation-name: slideInRight;">
                                    <h5>About VIP Courier and Cargo</h5>
                                    <h1>Next Business Day Delivery</h1>

                                    <ul>
                                        <li>
                                            <div class="cs_about_icon_box">
                                                <div class="cs_about_icon">
                                                    <img src="//unitedexpress.in/static/unitedexpress/frontendassets/images/index/about_img2.png" class="img-fluid" alt="images">
                                                </div>
                                                <div class="cs_about_icon_text">
                                                    <h3>Express Delivery</h3>
                                                    <p>Worldwide xpress Delivery At Door Step.</p>
                                                </div>
                                            </div>
                                        </li>
                                        <!--<li>
                                <div class="cs_about_icon_box">
                                    <div class="cs_about_icon">
                                        <img src="/static/unitedexpress/frontendassets/images/index/about_img3.png" class="img-fluid" alt="images">
                                    </div>
                                    <div class="cs_about_icon_text">
                                        <h3>Road Transport</h3>
                                        <p>Surface Delivery Depending on KMs By Destinations.</p>
                                    </div>
                                </div>
                            </li>-->
                                        <li>
                                            <div class="cs_about_icon_box">
                                                <div class="cs_about_icon">
                                                    <img src="//unitedexpress.in/static/unitedexpress/frontendassets/images/index/about_img4.png" class="img-fluid" alt="images">
                                                </div>
                                                <div class="cs_about_icon_text">
                                                    <h3>Delivery 4-5 Business Days</h3>
                                                    <p>Surface Delivery Long Destinations Depending By Train.</p>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="cs_about_icon_box">
                                                <div class="cs_about_icon">
                                                    <img src="//unitedexpress.in/static/unitedexpress/frontendassets/images/index/about_img4.png" class="img-fluid" alt="images">
                                                </div>
                                                <div class="cs_about_icon_text">
                                                    <h3>Delivery 10-12 Days</h3>
                                                    <p>Worldwide Shipping Economy Service Depending on Destinations.</p>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>





                <section class="cta-area">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-xl-10 col-lg-10">
                                <div class="cta-content">
                                    <h3>Are you Looking for Professional Courier Services. Please Contact Us</h3>
                                    <a href="contact" class="theme-btn btn-style-one"><span class="txt">Contact Us</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ripple_wrap">
                        <div class="left_bottom_ripples">
                            <div class="ripples"></div>
                        </div>
                        <div class="right_top_ripples">
                            <div class="ripples"></div>
                        </div>
                    </div>
                    <svg class="wave" width="1920px" height="150px" viewBox="0 0 1920 150">
                        <path fill="#fff" stroke-miterlimit="10" d="M0,150V83c0,0,460-167.25,1244.844-23.672C1790.298,159.113,1920,40,1920,40v110H0z"></path>
                    </svg>
                </section>



            </div>
        </div>
    </div>



    <div class="full-width goodhands">

        <section id="good-hands" class="section">
            <div class="container">
                <div class="intro">
                    <h2 class="heading" style="">You’re In Good Hands</h2>
                    <p class="sub text-muted" style="">
                        We're happy when our customers are happy. We pride ourselves on going above and beyond.
                    </p>
                </div>
                <div class="contents">
                    <div class="wrapper">
                        <img class="graphic" src="html/assets/about_photo.jpg" alt="good hands graphic">
                        <img class="graphic lg" src="html/assets/about_photo.jpg" alt="good hands graphic">
                    </div>
                    <ul class="points list-unstyled mb-0">
                        <li class="point">
                            <h3 class="heading" style="">Get the Help You Need, 24/7</h3>
                            <p class="text" style="">
                                We work around the clock to get your shipments to the right place at the right time. Our support center is second-to-none.
                            </p>
                        </li>
                        <li class="point">
                            <h3 class="heading" style="">Become a Shipping Expert</h3>
                            <p class="text" style="">
                                Our resource library has everything you've ever wanted to know about shipping.
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <style>
            #good-hands::before {
                background-color: #fff;
            }
        </style>
    </div>


    <div class="road-section-divider">
        <div class="contoiner-fluid">
            <div class="road-divider-content">
                <div class="road-border"> <img src="html/assets/truck.png" alt="car-item"> </div>
            </div>
        </div>
    </div>
    <footer id="main-footer" class="dark_style">
        <div class="container">


            <div class="row footer-cols">
                <div class="col-lg-4 col-md-6">
                    <aside id="footer_sidebar_1" class="sidebar-footer">
                        <section class="my-widget">
                            <div class="wpb_widgetised_column">
                                <div class="content-only widget bdaia-widget bdaia-box1">
                                    <div class="widget-box-title widget-box-title-s4">
                                        <h3>Contact</h3>
                                    </div>
                                    <p class="pra">Exceed your customer’s expectations with a curated delivery experience. Keep your customers informed with shipment tracking pages and emails that match your branding, and customized packing slips for a personal touch. Learn how to brand your delivery experience.</p>

                                </div>
                                <div class="widget content-only"></div>
                            </div>
                        </section>
                    </aside>
                </div>
                <div class="col-lg-4 col-md-6">
                    <aside id="footer_sidebar_2" class="sidebar-footer">
                        <section class="my-widget">
                            <div id="shipments-tracking" class="widget bdaia-widget widget_mc4wp_form_widget" style="">
                                <div class="widget-inner">
                                    <form class="form" action="track" method="POST">
                                        <input type="hidden" name="_token" value="TGvpPCLBaCZ7D12Nel9HY4Hc2i9nhe7tWgGifp2x">
                                        <div class="bdaia-mc4wp-form-icon">
                                            <span class="bdaia-io text-primary" style="line-height: 0">
                                                <svg style="width:auto; " height="58px" viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill="currentColor" d="m57.123 31.247v13.63h-12.247v-13.63zm3.925-4h27.552l-8.625-15.99h-20.155zm-18.868-15.99h-20.159l-8.621 15.99h27.551zm2.783 15.99h12.073l-1.229-15.99h-9.615zm2.03 44.992a25.612 25.612 0 0 1 .486-4.979h-19.888a5.133 5.133 0 0 0 -5.127 5.127v1.432a5.133 5.133 0 0 0 5.127 5.127h20.3a25.46 25.46 0 0 1 -.897-6.707zm7.393 17.875a25.231 25.231 0 0 1 -5.032-7.169h-21.763a9.137 9.137 0 0 1 -9.127-9.127v-1.431a9.137 9.137 0 0 1 9.127-9.127h21.04a25.28 25.28 0 0 1 41.507-8.9c.214.214.418.434.623.654v-23.767h-29.638v15.63a2 2 0 0 1 -2 2h-16.247a2 2 0 0 1 -2-2v-15.63h-29.638v60.185h44.58c-.49-.421-.97-.856-1.432-1.318zm10.36-23.922a2.08 2.08 0 0 0 -2.08 2.08v7.933a2.08 2.08 0 1 0 4.16 0v-7.932a2.08 2.08 0 0 0 -2.08-2.08zm9.6 2.08v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm7.516 0v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm-17.112-2.08a2.08 2.08 0 0 0 -2.08 2.08v7.933a2.08 2.08 0 1 0 4.16 0v-7.932a2.08 2.08 0 0 0 -2.084-2.08zm9.6 2.08v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm7.516 0v7.933a2.08 2.08 0 1 1 -4.16 0v-7.932a2.08 2.08 0 0 1 4.16 0zm11.673 3.967a21.292 21.292 0 1 1 -21.3-21.292 21.292 21.292 0 0 1 21.292 21.292zm-6.716 0a14.576 14.576 0 1 0 -14.584 14.576 14.576 14.576 0 0 0 14.576-14.576zm29.934 37.387a6.864 6.864 0 0 1 -6.974 7.1 8.6 8.6 0 0 1 -6.214-2.785l-14.663-15.651a1 1 0 0 1 .023-1.391l.977-.977-3.057-3.057a25.493 25.493 0 0 0 6.036-6.044l3.061 3.061.977-.977a1 1 0 0 1 1.391-.023l15.651 14.656a8.624 8.624 0 0 1 2.784 6.088zm-4 .066a4.608 4.608 0 0 0 -1.52-3.233l-13.537-12.672-3.89 3.888 12.671 13.532a4.586 4.586 0 0 0 3.294 1.52 2.868 2.868 0 0 0 2.974-3.034z"></path>
                                                </svg>
                                            </span>
                                        </div>

                                        <p class="bdaia-mc4wp-bform-p bd1-font" style="">
                                            Tracking Shipment
                                        </p>

                                        <p class="bdaia-mc4wp-bform-p2 bd2-font" style="">
                                            Enter your tracking code
                                        </p>

                                        <div class="mc4wp-form-fields">
                                            <p>
                                                <label style="">
                                                    Enter your tracking code
                                                </label>

                                                <input type="text" name="code" placeholder="AWB72704">
                                            </p>
                                            <p>
                                                <input type="submit" class="btn btn-submit submit" value="Search" style=" ">
                                            </p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </aside>
                </div>
                <div class="col-lg-4 col-md-6">
                    <aside id="footer_sidebar_3" class="sidebar-footer">
                        <section class="my-widget">
                            <section class="social-counters-widget">
                                <div class="wpb_widgetised_column">
                                    <div id="bdaia-widget-counter-2" class="content-only widget bdaia-widget bdaia-widget-counter">
                                        <div class="widget-box-title widget-box-title-s4">
                                            <h3>Stay Connected</h3>
                                        </div>
                                        <ul>
                                            <li class="mn"><i class="fa fa-address-card-o" aria-hidden="true"></i><a href="tel:98714 20063" class="text-white hb">Name - VIP courier & cargo Services</a></li>
                                            <li class="mn"><i class="fa fa-phone-volume"></i><a href="tel: 918920095642" class="text-white hb">918920095642</a></li>
                                            <li class="mn"><i class="fa fa-phone-volume"></i><a href="tel: 919650086730" class="text-white hb">919650086730</a></li>
                                            <li class="mn"><i class="fa fa-envelope-open-o" aria-hidden="true"></i><a href="mailto:info@vipcourierandcargo.com" class="text-white hb"> info@vipcourierandcargo.com</a></li>
                                        </ul>
                                        <!-- End Social Counter/-->
                                    </div>
                                    <div class="widget content-only"></div>
                                </div>
                            </section>

                        </section>
                    </aside>
                </div>
            </div>

            <div class="footer-bottom d-flex">
                <!-- dropdowns -->
                <div class="footer-col1">
                    <p class="copyright mb-0">© Copyright 2022 vipcourierandcargo.com, All Rights Reserved</p>
                </div>

                <!-- social media -->
                <div class="footer-col3">
                    <div class="widget-social-links bdaia-social-io-colored">
                        <div class="bdaia-social-io bdaia-social-io-size-35">
                            <a style="color: inherit;" class="none bdaia-io-url-facebook" title="Facebook" href="#" target="_blank"><span class="bdaia-io bdaia-io-facebook"></span></a>
                            <a style="color: inherit;" class="none bdaia-io-url-twitter" title="Facebook" href="#" target="_blank"><span class="bdaia-io bdaia-io-twitter"></span></a>
                            <a style="color: inherit;" class="none bdaia-io-url-google-plus" title="Facebook" href="#" target="_blank"><span class="bdaia-io bdaia-io-googleplus"></span></a>
                            <a style="color: inherit;" class="none bdaia-io-url-dribbble" title="Facebook" href="#" target="_blank"><span class="bdaia-io bdaia-io-dribbble"></span></a>
                            <a style="color: inherit;" class="none bdaia-io-url-youtube" title="Facebook" href="#" target="_blank"><span class="bdaia-io bdaia-io-youtube"></span></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </footer>


    <div id="myButton">
        <a href="//wa.me/+918920095642" target="_blank"> <img src="//unitedexpress.in/static/unitedexpress/frontendassets/images/whatsapp.svg" alt="call us on +918920095642
"></a>
    </div>
    <div id="myCall">
        <a href="tel:+918920095642
"><img src="//unitedexpress.in/static/unitedexpress/frontendassets/images/phone.svg" alt="call us"></a>
    </div>

    <div class="gotop" title="Go Top"><span class="bdaia-io bdaia-io-ion-android-arrow-up"></span></div>




    <script>
        WebFontConfig = {
            google: {
                families: ["Poppins:regular,500,600,700:latin", "Roboto:100,300,400,500,700,900:latin", "Open+Sans:400,600,700,800:latin"],
            },
        };
        (function() {
            var wf = document.createElement("script");
            wf.src = "//ajax.googleapis.com/ajax/libs/webfont/1/webfont.js";
            wf.type = "text/javascript";
            wf.async = "true";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
    <script type="text/javascript" src="html/assets/js/functions.js"></script>
    <script type="text/javascript" src="html/assets/js/sliders.js"></script>
    <script type="text/javascript" src="html/custom-assets/js/app.js"></script>

    <!-- <script src="//cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
    <script src="//cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script>
        feather.replace();
    </script>
    <script async="" src="//unpkg.com/typer-dot-js@0.1.0/typer.js"></script>
    <script src="html/easyship/assets/js/main.js"></script>

    <script>
        // ---------Responsive-navbar-active-animation-----------
        function test() {
            var tabsNewAnim = $('#navbarSupportedContent');
            var selectorNewAnim = $('#navbarSupportedContent').find('li').length;
            var activeItemNewAnim = tabsNewAnim.find('.active');
            var activeWidthNewAnimHeight = activeItemNewAnim.innerHeight();
            var activeWidthNewAnimWidth = activeItemNewAnim.innerWidth();
            var itemPosNewAnimTop = activeItemNewAnim.position();
            var itemPosNewAnimLeft = activeItemNewAnim.position();
            $(".hori-selector").css({
                "top": itemPosNewAnimTop.top + "px",
                "left": itemPosNewAnimLeft.left + "px",
                "height": activeWidthNewAnimHeight + "px",
                "width": activeWidthNewAnimWidth + "px"
            });
            $("#navbarSupportedContent").on("click", "li", function(e) {
                $('#navbarSupportedContent ul li').removeClass("active");
                $(this).addClass('active');
                var activeWidthNewAnimHeight = $(this).innerHeight();
                var activeWidthNewAnimWidth = $(this).innerWidth();
                var itemPosNewAnimTop = $(this).position();
                var itemPosNewAnimLeft = $(this).position();
                $(".hori-selector").css({
                    "top": itemPosNewAnimTop.top + "px",
                    "left": itemPosNewAnimLeft.left + "px",
                    "height": activeWidthNewAnimHeight + "px",
                    "width": activeWidthNewAnimWidth + "px"
                });
            });
        }
        $(document).ready(function() {
            setTimeout(function() {
                test();
            });
        });
        $(window).on('resize', function() {
            setTimeout(function() {
                test();
            }, 100);
        });
        $(".navbar-toggler").click(function() {
            $(".navbar-collapse").slideToggle(100);
            setTimeout(function() {
                test();
            });
        });



        // --------------add active class-on another-page move----------
        jQuery(document).ready(function($) {
            // Get current path and find target link
            var path = window.location.pathname.split("index.html").pop();

            // Account for home page with empty path
            if (path == '') {
                path = 'index-2.html';
            }

            var target = $('#navbarSupportedContent ul li a[href="' + path + '"]');
            // Add active class to target link
            target.parent().addClass('active');
        });




        // Add active class on another page linked
        // ==========================================
        // $(window).on('load',function () {
        //     var current = location.pathname;
        //     console.log(current);
        //     $('#navbarSupportedContent ul li a').each(function(){
        //         var $this = $(this);
        //         // if the current path is like this link, make it active
        //         if($this.attr('href').indexOf(current) !== -1){
        //             $this.parent().addClass('active');
        //             $this.parents('.menu-submenu').addClass('show-dropdown');
        //             $this.parents('.menu-submenu').parent().addClass('active');
        //         }else{
        //             $this.parent().removeClass('active');
        //         }
        //     })
        // });
    </script>






</body>

</html>